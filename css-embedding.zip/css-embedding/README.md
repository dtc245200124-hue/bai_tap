# Bài tập nhúng CSS vào trang HTML

Mở `index.html` bằng trình duyệt để xem ba phần minh họa.

## Ba cách nhúng CSS

**Inline style** được viết trực tiếp trong thuộc tính `style` của phần tử, ví dụ:

```html
<p style="color: #e67e22;">...</p>
```

**Internal style** được viết trong thẻ `<style>` bên trong phần `<head>` của file HTML.

**External style** được viết trong file `style.css` và liên kết bằng:

```html
<link rel="stylesheet" href="style.css">
```

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
