# Thực hành sử dụng Box Model 2

Mở file `index.html` bằng trình duyệt để xem kết quả.

Ví dụ gồm hai phần tử `div` lồng nhau. Phần tử bên ngoài sử dụng `margin: auto`, `padding: 35px`, chiều rộng `80px`, bóng trong màu `indianred` và bo tròn 50%.

Phần tử bên trong được chọn bằng bộ chọn con `div > div`, có `padding-bottom: 100px`, bo tròn 3% và bóng trong màu `seagreen`.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
