# Bài tập sử dụng thẻ hình ảnh

Mở file `index.html` bằng trình duyệt để xem hình ảnh.

Trang sử dụng:

```html
<img src="landscape.svg" alt="Phong cảnh núi xanh dưới bầu trời hoàng hôn nhiều màu sắc">
```

- `src` trỏ tới file hình ảnh cục bộ `landscape.svg`;
- `alt` mô tả nội dung hình ảnh để hỗ trợ khả năng truy cập và hiển thị khi ảnh không tải được.

Đưa toàn bộ thư mục lên GitHub và nộp link repository.
