# Thực hành tạo form tìm kiếm Google

Mở file `index.html` bằng trình duyệt.

## Form Google

```html
<form action="https://www.google.com.vn/search" method="GET">
    <input type="text" name="q" placeholder="Nhập từ khóa">
    <input type="submit" value="Tìm kiếm Google">
</form>
```

Khi nhập từ khóa và gửi form, trình duyệt tạo URL tương tự:

```text
https://www.google.com.vn/search?q=html
```

`action` là URL nhận dữ liệu, `method="GET"` gửi dữ liệu trên URL, còn `name="q"` là tên tham số mà Google Search sử dụng.

Trang cũng có một form Bing dùng `https://www.bing.com/search` và một form POST gửi thử tới `https://httpbin.org/post` để so sánh hai phương thức.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
