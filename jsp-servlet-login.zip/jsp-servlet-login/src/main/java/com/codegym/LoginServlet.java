package com.codegym;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "LoginServlet", urlPatterns = "/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        boolean authenticated = "admin".equals(username) && "admin".equals(password);

        response.setStatus(authenticated
                ? HttpServletResponse.SC_OK
                : HttpServletResponse.SC_UNAUTHORIZED);

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html lang=\"en\">");
            out.println("<head>");
            out.println("  <meta charset=\"UTF-8\">");
            out.println("  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
            out.println("  <title>Login Result</title>");
            out.println("  <style>body{font-family:Arial,sans-serif;text-align:center;margin:12vh auto;padding:24px;max-width:700px;background:#f8fafc;color:#172554}.success{color:#15803d}.error{color:#b91c1c}a{color:#1d4ed8}</style>");
            out.println("</head>");
            out.println("<body>");
            if (authenticated) {
                out.println("  <h1 class=\"success\">Welcome admin to website</h1>");
            } else {
                out.println("  <h1 class=\"error\">Login Error</h1>");
            }
            out.println("  <p><a href=\"" + request.getContextPath() + "/\">Go back</a></p>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/");
    }
}
