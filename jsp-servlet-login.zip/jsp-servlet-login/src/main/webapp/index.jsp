<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>System Login</title>
    <style>
        * { box-sizing: border-box; }
        body { min-height: 100vh; display: grid; place-items: center; margin: 0; padding: 24px; font-family: Arial, sans-serif; background: #f1f5f9; color: #172554; }
        .login-card { width: min(100%, 390px); padding: 32px; background: white; border-radius: 12px; box-shadow: 0 12px 32px rgba(15, 23, 42, .12); }
        h1 { margin: 0 0 8px; text-align: center; font-size: 1.7rem; }
        .hint { margin: 0 0 24px; text-align: center; color: #64748b; }
        label { display: block; margin: 16px 0 6px; font-weight: 600; }
        input { width: 100%; padding: 11px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font: inherit; }
        input:focus { outline: 2px solid #93c5fd; border-color: #2563eb; }
        button { width: 100%; margin-top: 22px; padding: 12px; border: 0; border-radius: 6px; background: #1b2a7a; color: white; font: inherit; font-weight: 700; cursor: pointer; }
        button:hover { background: #263aa0; }
    </style>
</head>
<body>
    <main class="login-card">
        <h1>System Login</h1>
        <p class="hint">Enter your username and password to continue.</p>
        <form action="${pageContext.request.contextPath}/login" method="POST">
            <label for="username">Username</label>
            <input id="username" type="text" name="username" autocomplete="username" required>
            <label for="password">Password</label>
            <input id="password" type="password" name="password" autocomplete="current-password" required>
            <button type="submit">Login</button>
        </form>
    </main>
</body>
</html>
