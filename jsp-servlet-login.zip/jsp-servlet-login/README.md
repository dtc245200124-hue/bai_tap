# JSP/Servlet Login Demo

Bài thực hành form đăng nhập dùng Java 17, JSP 3.1 và Jakarta Servlet 6.0, tương thích Apache Tomcat 10.1+.

## Chức năng

Trang chủ có form gửi `username` và `password` bằng phương thức `POST` tới `/login`. Tài khoản mẫu cố định cho bài thực hành là `admin` / `admin`. Khi thông tin đúng, ứng dụng hiển thị `Welcome admin to website`; nếu sai, hiển thị `Login Error`.

> Đây chỉ là ví dụ học tập: thông tin đăng nhập được hardcode và không phù hợp dùng trong môi trường thật.

## Build

Cần Java 17+ và Maven. Từ thư mục gốc dự án chạy:

```bash
mvn clean package
```

Sau khi Maven báo `BUILD SUCCESS`, file WAR sẽ có tại `target/jsp-servlet-login.war`.

## Chạy trên Tomcat

Sao chép WAR vào thư mục `webapps` của Tomcat 10.1+ và khởi động máy chủ. Mở `http://localhost:8080/jsp-servlet-login/` để thử đăng nhập.
