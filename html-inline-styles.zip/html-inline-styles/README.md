# Bài tập định dạng văn bản với HTML Styles

Mở file `index.html` bằng trình duyệt để kiểm tra kết quả.

Trang đã sử dụng CSS nội tuyến:

- `h1` màu xanh dương với `color: blue`;
- Đoạn văn màu đỏ và in đậm với `color: red` và `font-weight: bold`;
- Đoạn văn in nghiêng và căn giữa với `font-style: italic` và `text-align: center`;
- Đoạn văn cỡ chữ 20px và gạch chân với `font-size: 20px` và `text-decoration: underline`.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
