# Thực hành sử dụng Box Model 3

Mở file `index.html` bằng trình duyệt để xem kết quả.

Ví dụ sử dụng một container `#demo` có `display: flex`, chiều rộng 350px, viền đen và bo tròn. Hai phần tử con `.d1` và `.d2` có cùng kích thước, nhưng sử dụng màu bóng và padding khác nhau.

- `.d1` có `margin-left: 20px` và bóng `mediumslateblue`;
- `.d2` có `padding: 30px` và bóng `darkred`;
- `box-sizing: border-box` giữ kích thước phần tử bao gồm cả padding;
- `border-radius: 36%` tạo góc bo tròn cho hai hộp.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
