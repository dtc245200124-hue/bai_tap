-- [Bài tập] Xây dựng CSDL quản lý sinh viên
-- Tiếp tục sử dụng database student-management.
CREATE DATABASE IF NOT EXISTS `student-management`;
USE `student-management`;

CREATE TABLE IF NOT EXISTS `Class` (
    `id` INT,
    `name` VARCHAR(200)
);

CREATE TABLE IF NOT EXISTS `Teacher` (
    `id` INT,
    `name` VARCHAR(200),
    `age` INT,
    `country` VARCHAR(50)
);
