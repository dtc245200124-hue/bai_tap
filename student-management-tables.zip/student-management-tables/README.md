# Bài tập xây dựng CSDL quản lý sinh viên

## Yêu cầu

Trong database `student-management`, tạo hai bảng:

### Bảng `Class`

- `id` kiểu `INT`;
- `name` kiểu `VARCHAR(200)`.

### Bảng `Teacher`

- `id` kiểu `INT`;
- `name` kiểu `VARCHAR(200)`;
- `age` kiểu `INT`;
- `country` kiểu `VARCHAR(50)`.

## Thực hiện bằng MySQL Workbench

1. Mở MySQL Workbench và đăng nhập MySQL Server.
2. Mở **New Query Tab**.
3. Mở file `create_class_teacher.sql` hoặc dán các câu lệnh:

```sql
CREATE DATABASE IF NOT EXISTS `student-management`;
USE `student-management`;

CREATE TABLE IF NOT EXISTS `Class` (
    `id` INT,
    `name` VARCHAR(200)
);

CREATE TABLE IF NOT EXISTS `Teacher` (
    `id` INT,
    `name` VARCHAR(200),
    `age` INT,
    `country` VARCHAR(50)
);
```

4. Nhấn biểu tượng tia sét **Execute**.
5. Refresh khu vực **SCHEMAS**.
6. Mở database `student-management` → **Tables** để kiểm tra `Class` và `Teacher`.
7. Chạy file `verify_tables.sql` để kiểm tra cấu trúc:

```sql
USE `student-management`;
SHOW TABLES;
DESCRIBE `Class`;
DESCRIBE `Teacher`;
```

## Chạy bằng terminal (tùy chọn)

```bash
mysql -u root -p < create_class_teacher.sql
mysql -u root -p < verify_tables.sql
```

Tên database có dấu gạch ngang nên phải đặt trong backtick như `` `student-management` ``.
Không đưa mật khẩu MySQL lên GitHub.
