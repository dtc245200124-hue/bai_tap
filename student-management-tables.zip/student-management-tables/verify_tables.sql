USE `student-management`;

SHOW TABLES;
DESCRIBE `Class`;
DESCRIBE `Teacher`;
