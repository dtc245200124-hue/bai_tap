# Bài tập sử dụng Box Model 2 - Open Source Records

Mở `index.html` bằng trình duyệt để xem trang đã hoàn thiện từ mã nguồn cho trước.

Phần CSS đã bổ sung các thuộc tính Box Model và bố cục cho `body`, `h1`, `h2`, `h3`, `ul`, `li`, `p`, `a`: chiều rộng, margin, padding, border, màu sắc, font chữ, danh sách menu ngang, khoảng cách nội dung và hiệu ứng hover cho liên kết.

Các trang `about.html`, `bands.html` và `contact.html` được tạo thêm để các liên kết menu hoạt động.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
