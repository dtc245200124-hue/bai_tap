# Bài tập sử dụng danh sách trong HTML

Mở file `index.html` bằng trình duyệt để xem kết quả.

Trang gồm:

- Tiêu đề `<h1>`: **Những món ăn yêu thích của tôi**;
- Danh sách không có thứ tự `<ul>` với sáu món ăn;
- Tiêu đề `<h2>`: **Các bước chuẩn bị cho một chuyến du lịch**;
- Danh sách có thứ tự `<ol>` với sáu bước chuẩn bị.

Đưa file này lên GitHub và nộp link repository.
