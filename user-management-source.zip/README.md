# User Management JDBC

Đây là bộ khung Maven Webapp cho bài tập quản lý User bằng MVC, JDBC, MySQL, Servlet, JSP và JSTL. Dự án tương thích Apache Tomcat 10.1+.

Theo đúng yêu cầu của đề bài, `pom.xml` và `WEB-INF/web.xml` đã được cấu hình hoàn chỉnh. Các class Java và JSP hiện chỉ là skeleton có Javadoc/TODO, chưa có mã CRUD, xử lý JDBC hoặc giao diện hoàn thiện để bạn tự thực hành.

## Khởi tạo MySQL

Mở MySQL Workbench, DBeaver hoặc terminal rồi chạy nội dung trong `schema.sql`. Script tạo database `demo`, bảng `users` và hai bản ghi mẫu.

## Cấu hình kết nối

Khi tự triển khai `UserDAO`, hãy cập nhật JDBC URL, username và password theo MySQL trên máy của bạn. Không đưa mật khẩu thật lên GitHub; nên dùng biến môi trường hoặc file cấu hình nằm ngoài repository.

## Cấu trúc dự án

```text
user-management/
├── pom.xml
├── schema.sql
├── README.md
└── src/main/
    ├── java/com/codegym/
    │   ├── model/User.java
    │   ├── dao/IUserDAO.java
    │   ├── dao/UserDAO.java
    │   └── controller/UserServlet.java
    └── webapp/
        ├── WEB-INF/web.xml
        └── user/
            ├── list.jsp
            ├── create.jsp
            ├── edit.jsp
            └── delete.jsp
```

## Build

```bash
mvn clean package
```

File WAR sau khi hoàn thiện sẽ nằm tại `target/user-management.war`.
