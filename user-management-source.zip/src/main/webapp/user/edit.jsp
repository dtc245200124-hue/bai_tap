<%--
    User edit view skeleton.
    TODO: Add the form for updating name, email, and country.
--%>
