<%--
    User list view skeleton.
    TODO: Add Jakarta JSTL declarations and the user table.
--%>
