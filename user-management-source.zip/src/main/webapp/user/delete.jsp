<%--
    User deletion view skeleton.
    TODO: Add the delete confirmation form.
--%>
