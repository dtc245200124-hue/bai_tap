<%--
    User creation view skeleton.
    TODO: Add the form for name, email, and country.
--%>
