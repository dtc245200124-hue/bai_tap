package com.codegym.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;

/**
 * Controller skeleton for user CRUD requests.
 *
 * TODO: Inject UserDAO, route GET/POST actions, and forward to JSP views.
 */
@WebServlet(name = "UserServlet", urlPatterns = "/users")
public class UserServlet extends HttpServlet {
    // TODO: Implement controller request handling.
}
