package com.codegym.model;

/**
 * Model skeleton representing a database user.
 *
 * TODO: Declare id, name, email, and country fields, constructors, getters,
 * and setters as part of the JDBC exercise.
 */
public class User {
    // TODO: Add model fields and accessors.
}
