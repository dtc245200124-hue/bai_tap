package com.codegym.dao;

import com.codegym.model.User;
import java.util.List;

/**
 * DAO contract for JDBC user CRUD operations.
 *
 * TODO: Declare insert, select-by-id, select-all, delete, and update methods.
 */
public interface IUserDAO {
    // TODO: Add CRUD method signatures.
}
