# Thực hành gộp ô trong bảng với rowspan và colspan

Mở file `index.html` bằng trình duyệt để xem kết quả.

Bảng thời khóa biểu có các cột **Thứ**, **Môn học** và **Giáo viên**.

- `rowspan="2"` gộp ô **Thứ Hai** qua hai hàng môn học;
- `colspan="2"` gộp hai cột **Môn học** và **Giáo viên** thành ô **Nghỉ học**;
- `border="1"` hiển thị đường viền bảng.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
