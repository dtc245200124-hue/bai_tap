# Bài tập tạo giao diện form đăng ký người dùng

Mở `index.html` bằng trình duyệt để xem form.

Form được cấu hình đúng theo yêu cầu:

```html
<form action="http://demo.codegym.vn/6/registration_form/register.php" method="POST">
```

Các trường sử dụng đúng tên:

| Nhãn | `name` |
|---|---|
| Họ và tên | `name` |
| Email | `email` |
| Số điện thoại | `phone` |
| Giới tính | `gender` |

Khi nhấn **Đăng ký**, trình duyệt gửi dữ liệu bằng phương thức `POST` đến server CodeGym. Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
