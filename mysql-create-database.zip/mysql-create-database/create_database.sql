-- [Thực hành] Tạo CSDL trên MySQL Workbench
-- Tạo database an toàn nếu database chưa tồn tại.
CREATE DATABASE IF NOT EXISTS `my_database1`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

-- Chọn database vừa tạo để sẵn sàng cho các bài tiếp theo.
USE `my_database1`;
