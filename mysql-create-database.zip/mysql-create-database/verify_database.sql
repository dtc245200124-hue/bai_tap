-- Kiểm tra database đã được tạo chưa.
SHOW DATABASES LIKE 'my_database1';

-- Kiểm tra database hiện đang được chọn.
SELECT DATABASE() AS current_database;
