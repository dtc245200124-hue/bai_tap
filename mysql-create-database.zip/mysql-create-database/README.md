# Thực hành tạo CSDL trên MySQL Workbench

## Cách 1: Tạo bằng giao diện

1. Mở MySQL Workbench và đăng nhập vào MySQL Server.
2. Trong khu vực **SCHEMAS**, chọn biểu tượng tạo schema mới hoặc nhấp chuột phải vào vùng SCHEMAS và chọn **Create Schema**.
3. Nhập tên:

   ```text
   my_database1
   ```

4. Nhấn **Apply**.
5. Kiểm tra câu lệnh được sinh ra, nhấn **Apply** lần nữa và chọn **Finish**.
6. Nhấn Refresh trong khu vực **SCHEMAS**. Database `my_database1` sẽ xuất hiện.

## Cách 2: Tạo bằng câu lệnh SQL

1. Mở một **New Query Tab**.
2. Mở file `create_database.sql` hoặc dán câu lệnh sau:

```sql
CREATE DATABASE IF NOT EXISTS `my_database1`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
USE `my_database1`;
```

3. Nhấn biểu tượng tia sét **Execute**.
4. Chạy file `verify_database.sql` để kiểm tra:

```sql
SHOW DATABASES LIKE 'my_database1';
SELECT DATABASE() AS current_database;
```

Kết quả cần thấy database `my_database1` và current database là `my_database1`.

## Chạy bằng terminal (tùy chọn)

```bash
mysql -u root -p < create_database.sql
mysql -u root -p < verify_database.sql
```

Không đưa mật khẩu MySQL lên GitHub.
