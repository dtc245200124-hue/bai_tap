<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Chuyển đổi USD sang VNĐ</title>
    <style>
        * { box-sizing: border-box; }
        body { min-height: 100vh; display: grid; place-items: center; margin: 0; padding: 24px; font-family: Arial, sans-serif; background: #f1f5f9; color: #172554; }
        .converter-card { width: min(100%, 420px); padding: 32px; background: #fff; border-radius: 12px; box-shadow: 0 12px 32px rgba(15, 23, 42, .12); }
        h1 { margin: 0 0 8px; text-align: center; font-size: 1.6rem; }
        .intro { margin: 0 0 24px; text-align: center; color: #64748b; }
        label { display: block; margin: 16px 0 6px; font-weight: 600; }
        input { width: 100%; padding: 11px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font: inherit; }
        input:focus { outline: 2px solid #93c5fd; border-color: #2563eb; }
        button { width: 100%; margin-top: 22px; padding: 12px; border: 0; border-radius: 6px; background: #1b2a7a; color: white; font: inherit; font-weight: 700; cursor: pointer; }
        button:hover { background: #263aa0; }
        .note { margin: 16px 0 0; color: #64748b; font-size: .875rem; text-align: center; }
    </style>
</head>
<body>
    <main class="converter-card">
        <h1>Chuyển đổi USD sang VNĐ</h1>
        <p class="intro">Nhập tỉ giá và số USD cần chuyển đổi.</p>
        <form action="${pageContext.request.contextPath}/convert" method="POST">
            <label for="rate">Tỉ giá (VNĐ/USD)</label>
            <input id="rate" type="number" name="rate" value="25000" min="0.000001" step="any" required>
            <label for="usd">Lượng USD</label>
            <input id="usd" type="number" name="usd" placeholder="Ví dụ: 100" min="0" step="any" required>
            <button type="submit">Chuyển đổi</button>
        </form>
        <p class="note">Tỉ giá được nhập thủ công và không cập nhật trực tuyến.</p>
    </main>
</body>
</html>
