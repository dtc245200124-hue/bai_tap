package com.codegym;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "ConverterServlet", urlPatterns = "/convert")
public class ConverterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        BigDecimal rate;
        BigDecimal usd;
        try {
            String rateValue = request.getParameter("rate");
            String usdValue = request.getParameter("usd");
            if (rateValue == null || usdValue == null
                    || rateValue.isBlank() || usdValue.isBlank()) {
                throw new NumberFormatException("Missing input");
            }
            rate = new BigDecimal(rateValue.trim());
            usd = new BigDecimal(usdValue.trim());
            if (rate.signum() <= 0 || usd.signum() < 0) {
                throw new NumberFormatException("Values out of range");
            }
        } catch (NumberFormatException ex) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            writePage(response, request, null, null, null,
                    "Vui lòng nhập tỉ giá lớn hơn 0 và lượng USD không âm bằng số hợp lệ.");
            return;
        }

        BigDecimal vnd = usd.multiply(rate).setScale(2, RoundingMode.HALF_UP);
        writePage(response, request, rate, usd, vnd, null);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/");
    }

    private void writePage(HttpServletResponse response, HttpServletRequest request,
                           BigDecimal rate, BigDecimal usd, BigDecimal vnd, String error)
            throws IOException {
        NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.forLanguageTag("vi-VN"));
        numberFormat.setMaximumFractionDigits(2);
        numberFormat.setMinimumFractionDigits(0);

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html lang=\"vi\">");
            out.println("<head>");
            out.println("  <meta charset=\"UTF-8\">");
            out.println("  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
            out.println("  <title>Kết quả chuyển đổi</title>");
            out.println("  <style>body{font-family:Arial,sans-serif;text-align:center;margin:12vh auto;padding:24px;max-width:760px;background:#f8fafc;color:#172554}.card{padding:32px;background:white;border-radius:12px;box-shadow:0 12px 32px #0f17221f}.result{color:#15803d;font-size:1.5rem;font-weight:700}.error{color:#b91c1c;font-weight:700}a{display:inline-block;margin-top:16px;padding:10px 18px;border-radius:6px;background:#1b2a7a;color:white;text-decoration:none}</style>");
            out.println("</head>");
            out.println("<body><main class=\"card\">");
            out.println("  <h1>Kết quả chuyển đổi</h1>");
            if (error != null) {
                out.println("  <p class=\"error\">" + error + "</p>");
            } else {
                out.println("  <p>Tỉ giá: " + numberFormat.format(rate) + " VNĐ/USD</p>");
                out.println("  <p>Lượng USD: " + numberFormat.format(usd) + " USD</p>");
                out.println("  <p class=\"result\">Thành tiền: " + numberFormat.format(vnd) + " VNĐ</p>");
            }
            out.println("  <a href=\"" + request.getContextPath() + "/\">Quay lại</a>");
            out.println("</main></body></html>");
        }
    }
}
