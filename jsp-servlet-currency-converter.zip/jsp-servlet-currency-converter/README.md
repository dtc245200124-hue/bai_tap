# USD to VND Currency Converter

Bài thực hành Java Web dùng JSP và Jakarta Servlet 6.0, tương thích Apache Tomcat 10.1+.

Trang chủ có form gửi tỉ giá `rate` và lượng USD `usd` bằng phương thức POST tới `/convert`. Servlet tính `VNĐ = USD × Tỉ giá`, sử dụng `BigDecimal` để tránh sai số số thực, và định dạng kết quả theo kiểu số Việt Nam. Tỉ giá mặc định là 25.000 VNĐ/USD, người dùng có thể thay đổi. Tỉ giá được nhập thủ công; ứng dụng không kết nối dịch vụ dữ liệu tỉ giá trực tuyến.

## Build

Cần Java 17+ và Maven. Chạy từ thư mục gốc của dự án:

```bash
mvn clean package
```

Sau khi Maven báo `BUILD SUCCESS`, WAR nằm tại `target/jsp-servlet-currency-converter.war`.

## Chạy trên Tomcat

Sao chép WAR vào thư mục `webapps` của Tomcat 10.1+ và khởi động máy chủ. Mở `http://localhost:8080/jsp-servlet-currency-converter/`, nhập tỉ giá (ví dụ `25000`) và số USD, rồi bấm **Chuyển đổi**.
