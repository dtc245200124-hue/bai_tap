package com.codegym;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "HelloServlet", urlPatterns = "/hello")
public class HelloServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html lang=\"vi\">");
            out.println("<head>");
            out.println("  <meta charset=\"UTF-8\">");
            out.println("  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
            out.println("  <title>Hello Servlet</title>");
            out.println("  <style>body{font-family:Arial,sans-serif;text-align:center;margin:10vh auto;max-width:760px;padding:24px;color:#172554;background:#f8fafc}a{color:#1d4ed8}</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("  <h1>Chào mừng bạn đến với Servlet đầu tiên!</h1>");
            out.println("  <p>Ứng dụng JSP/Servlet đang chạy trên Jakarta Servlet và Tomcat 10.1+.</p>");
            out.println("  <p><a href=\"index.jsp\">Quay lại trang chủ</a></p>");
            out.println("</body>");
            out.println("</html>");
        }
    }
}
