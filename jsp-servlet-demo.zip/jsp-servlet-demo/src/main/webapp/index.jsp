<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.time.ZonedDateTime, java.time.format.DateTimeFormatter" %>
<%
    ZonedDateTime serverTime = ZonedDateTime.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss z");
    String formattedTime = serverTime.format(formatter);
%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CodeGym JSP Demo</title>
    <style>
        :root { color-scheme: light; }
        body { font-family: Arial, sans-serif; text-align: center; margin: 10vh auto; padding: 24px; max-width: 760px; background: #f8fafc; color: #172554; }
        h1 { font-size: clamp(2rem, 5vw, 3rem); }
        .time { color: #ea580c; font-size: 1.35rem; font-weight: 700; }
        a { display: inline-block; margin-top: 18px; padding: 12px 20px; border-radius: 6px; background: #1b2a7a; color: white; text-decoration: none; }
        a:hover { background: #263aa0; }
    </style>
</head>
<body>
    <h1>Chào mừng tới lớp học Java Web!</h1>
    <p>Đây là trang JSP động được xử lý bởi Tomcat Server.</p>
    <p>Thời gian hệ thống hiện tại của máy chủ:</p>
    <p class="time"><%= formattedTime %></p>
    <a href="${pageContext.request.contextPath}/hello">Đi tới HelloServlet</a>
</body>
</html>
