# JSP/Servlet hiển thị thời gian hệ thống

Ứng dụng Maven Web (WAR) mẫu sử dụng Java 17, Jakarta Servlet 6.0 và JSP 3.1, tương thích với Apache Tomcat 10.1+. Trang chủ hiển thị thời gian hệ thống của máy chủ; endpoint `/hello` là servlet mẫu.

## Cấu trúc

```text
jsp-servlet-demo/
├── pom.xml
└── src/main/
    ├── java/com/codegym/HelloServlet.java
    └── webapp/
        ├── index.jsp
        └── WEB-INF/web.xml
```

## Đóng gói

Cần cài Java 17+ và Maven. Chạy tại thư mục có `pom.xml`:

```bash
mvn clean package
```

Sau khi build thành công, WAR nằm tại `target/jsp-servlet-demo.war`.

## Chạy trên Tomcat

Sao chép `target/jsp-servlet-demo.war` vào thư mục `webapps` của Tomcat 10.1+, rồi khởi động Tomcat. Truy cập:

- Trang chủ: `http://localhost:8080/jsp-servlet-demo/`
- Servlet: `http://localhost:8080/jsp-servlet-demo/hello`

Thời gian trên trang chủ lấy từ đồng hồ và múi giờ hệ thống của máy chủ đang chạy Tomcat.
