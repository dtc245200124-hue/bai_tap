# Market Research Survey

Đây là form survey khách hàng được dựng lại theo mẫu Wufoo được cung cấp.

Form gồm các nhóm câu hỏi:

- Độ tuổi, thu nhập năm và giới tính;
- Các sản phẩm đã mua trong hai tháng gần đây;
- Tần suất sử dụng sản phẩm mới;
- Mức giá người dùng sẵn sàng chi trả;
- Ô nhập tính năng mong muốn;
- Bảng đánh giá bốn mức độ: Strongly Disagree, Disagree, Agree, Strongly Agree.

Mở `index.html` bằng trình duyệt để xem giao diện. Form hiện dùng `action="#"` để minh họa giao diện, chưa gửi tới server cụ thể.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
