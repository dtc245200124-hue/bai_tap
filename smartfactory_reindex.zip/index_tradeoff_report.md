# Báo cáo đánh đổi Index của SmartFactory

## Kết luận

`idx_fat_covering` bao phủ toàn bộ các cột lọc và cột trả về của Dashboard, nên truy vấn có thể đọc trực tiếp từ cây index. Đây là lợi thế của **Covering Index**: giảm table lookup và thường làm `EXPLAIN` xuất hiện `Using index`. Tuy nhiên, SmartFactory là hệ thống ghi liên tục. Mỗi bản ghi cảm biến mới phải được chèn vào một cấu trúc index rất rộng, trong đó có `temperature`, `humidity` và `status`. Các cột này thay đổi theo từng bản ghi và làm tăng số byte phải ghi, số trang index cần duy trì, bộ nhớ đệm và I/O.

Giải pháp thay thế là `idx_lean_search(sensor_id, recorded_at)`. Hai cột này đủ để lọc cảm biến và giới hạn khoảng thời gian. Sau khi tìm được khóa phù hợp, MySQL đọc bảng gốc để lấy ba cột kết quả. Vì vậy, `SELECT` có thể chậm hơn một phần nhỏ và `Extra` thường không còn `Using index`. Đổi lại, index nhỏ hơn, thao tác `INSERT` chịu ít write penalty hơn và chi phí SSD giảm. Việc kiểm chứng dùng `SHOW TABLE STATUS`, `information_schema.TABLES`, `SHOW INDEX` và `EXPLAIN` trước/sau. Không tự tạo số liệu dung lượng khi chưa chạy trên dữ liệu thật; cần ghi lại `INDEX_LENGTH` thực tế sau khi triển khai.

## Thiết kế

| Phương án | Lợi ích | Chi phí |
|---|---|---|
| `idx_fat_covering` | Đọc Dashboard nhanh, có thể không cần table lookup | Index lớn, ghi chậm, tốn RAM và SSD |
| `idx_lean_search` | Đủ lọc theo cảm biến/thời gian, ghi và lưu trữ nhẹ hơn | Phải lookup bảng để lấy dữ liệu đo |

Covering Index vẫn hợp lý cho bảng ít ghi và truy vấn đọc áp đảo. Với luồng IoT có hàng chục nghìn bản ghi mỗi giây, cân bằng tổng thể quan trọng hơn tốc độ của một truy vấn đơn lẻ.

## References

[1]: https://dev.mysql.com/doc/refman/8.0/en/covering-indexes.html "MySQL 8.0 Reference Manual: Covering Indexes"

[2]: https://dev.mysql.com/doc/refman/8.0/en/clustered-index.html "MySQL 8.0 Reference Manual: Clustered and Secondary Indexes"

[3]: https://dev.mysql.com/doc/refman/8.0/en/optimization-indexes.html "MySQL 8.0 Reference Manual: Optimization and Indexes"
