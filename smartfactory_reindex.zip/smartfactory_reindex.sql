-- SmartFactory: cân bằng Read, Write và Storage
-- Thay thế Covering Index quá lớn bằng Lean Index phục vụ lọc/sắp xếp.

CREATE DATABASE IF NOT EXISTS smartfactory_db;
USE smartfactory_db;

-- Dùng phần này nếu SensorLogs chưa tồn tại.
CREATE TABLE IF NOT EXISTS SensorLogs (
    log_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    sensor_id INT NOT NULL,
    recorded_at DATETIME NOT NULL,
    temperature DECIMAL(5, 2),
    humidity DECIMAL(5, 2),
    status VARCHAR(20)
);

-- ============================================================
-- 1. Ghi nhận hiện trạng của Fat Index
-- ============================================================
SHOW TABLE STATUS LIKE 'SensorLogs';

SELECT
    TABLE_NAME,
    ROUND(DATA_LENGTH / 1024 / 1024, 2) AS data_size_mb,
    ROUND(INDEX_LENGTH / 1024 / 1024, 2) AS index_size_mb,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS total_size_mb,
    TABLE_ROWS AS estimated_rows
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'SensorLogs';

SHOW INDEX FROM SensorLogs;

-- Truy vấn Dashboard trước khi thay đổi index.
EXPLAIN
SELECT temperature, humidity, status
FROM SensorLogs
WHERE sensor_id = 105
  AND recorded_at >= '2026-06-20';

-- ============================================================
-- 2. Thay thế Fat Index bằng Lean Index
-- ============================================================
-- Fat Index bao phủ cả các cột dữ liệu thường xuyên thay đổi.
ALTER TABLE SensorLogs
    DROP INDEX idx_fat_covering;

-- Lean Index chỉ giữ các cột dùng để lọc và xác định phạm vi thời gian.
CREATE INDEX idx_lean_search
    ON SensorLogs(sensor_id, recorded_at);

ANALYZE TABLE SensorLogs;

-- ============================================================
-- 3. Kiểm tra sau tối ưu
-- ============================================================
SHOW TABLE STATUS LIKE 'SensorLogs';

SELECT
    TABLE_NAME,
    ROUND(DATA_LENGTH / 1024 / 1024, 2) AS data_size_mb,
    ROUND(INDEX_LENGTH / 1024 / 1024, 2) AS index_size_mb,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS total_size_mb,
    TABLE_ROWS AS estimated_rows
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'SensorLogs';

SHOW INDEX FROM SensorLogs;

-- Sau tối ưu, key kỳ vọng là idx_lean_search.
-- Extra thường không còn 'Using index' vì phải đọc bảng gốc
-- để lấy temperature, humidity và status.
EXPLAIN
SELECT temperature, humidity, status
FROM SensorLogs
WHERE sensor_id = 105
  AND recorded_at >= '2026-06-20';
