# AI Prompt Log — SmartFactory Index Trade-off

## Prompt 1: Covering Index

**Câu hỏi:**

> Covering Index trong MySQL là gì và vì sao nó có thể làm truy vấn Dashboard nhanh hơn?

**Tóm tắt kết quả:**

Covering Index chứa đủ các cột cần cho điều kiện lọc và danh sách kết quả. Nếu trình tối ưu có thể lấy toàn bộ dữ liệu từ index, MySQL không phải quay lại bảng gốc. Điều này giảm table lookup và I/O. Lợi ích chỉ đáng kể khi truy vấn đọc thường xuyên và chi phí duy trì index vẫn chấp nhận được.

## Prompt 2: Clustered Index và Secondary Index

**Câu hỏi:**

> InnoDB tổ chức dữ liệu trong Clustered Index và Secondary Index như thế nào? Điều đó ảnh hưởng ra sao đến index phụ có nhiều cột?

**Tóm tắt kết quả:**

Trong InnoDB, khóa chính là clustered index và bản ghi dữ liệu nằm trong các trang của cây đó. Secondary Index lưu khóa của các cột được lập chỉ mục cùng với khóa chính để xác định bản ghi. Khi secondary index quá rộng, mỗi trang chứa ít mục hơn, cây có thể lớn hơn và tốn thêm bộ nhớ/đĩa. Nếu truy vấn không được covering, MySQL phải đi tiếp từ secondary index đến clustered index để lấy cột còn thiếu.

## Prompt 3: Write Penalty

**Câu hỏi:**

> Vì sao thêm nhiều cột vào composite index làm INSERT trong hệ thống IoT chậm hơn?

**Tóm tắt kết quả:**

Mỗi INSERT phải thêm một mục vào từng index liên quan. Index rộng làm tăng lượng dữ liệu cần ghi và có thể làm tăng số lần phân trang, cập nhật page và I/O. Với hệ thống có tốc độ ghi cao, chi phí này lặp lại cho hàng triệu bản ghi. Đây là write penalty của index. Cần chỉ lập index cho các cột thật sự phục vụ lọc, nối hoặc sắp xếp.

## Prompt 4: Đánh giá phương án

**Câu hỏi:**

> Với truy vấn lọc theo sensor_id và recorded_at nhưng trả về temperature, humidity, status, nên chọn index nào cho hệ thống ghi liên tục?

**Tóm tắt kết quả:**

`(sensor_id, recorded_at)` là lean index phù hợp để tìm đúng cảm biến và khoảng thời gian. Truy vấn phải lookup bảng gốc để đọc các cột đo, nên có thể mất thêm thời gian rất nhỏ so với covering index. Đổi lại, index ít tốn storage và giảm chi phí ghi. Cần kiểm chứng bằng `EXPLAIN`, `INDEX_LENGTH` và benchmark trên dữ liệu có kích thước gần thực tế.

## Ghi chú triển khai

Các prompt chỉ được dùng để hiểu khái niệm và phản biện thiết kế. Script cuối cùng tự giữ hai cột trong `WHERE` và `ORDER BY` là `sensor_id`, `recorded_at`; không đưa các cột kết quả biến động vào index. Không ghi nhận phần trăm hoặc tốc độ cụ thể nếu chưa đo trên hệ thống thực tế.
