document.addEventListener("DOMContentLoaded", function () {
  const menuButton = document.querySelector(".menu-icon");
  const navLinks = document.querySelector(".nav-links");
  const menuGlyph = document.querySelector(".menu-glyph");

  if (!menuButton || !navLinks || !menuGlyph) return;

  function setMenuOpen(isOpen) {
    navLinks.classList.toggle("is-open", isOpen);
    menuButton.setAttribute("aria-expanded", String(isOpen));
    menuButton.setAttribute("aria-label", isOpen ? "Đóng menu" : "Mở menu");
    menuGlyph.textContent = isOpen ? "×" : "☰";
  }

  menuButton.addEventListener("click", function () {
    const isOpen = menuButton.getAttribute("aria-expanded") === "true";
    setMenuOpen(!isOpen);
  });

  navLinks.addEventListener("click", function (event) {
    if (event.target.closest("a")) setMenuOpen(false);
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") setMenuOpen(false);
  });

  window.addEventListener("resize", function () {
    if (window.innerWidth > 760) setMenuOpen(false);
  });
});
