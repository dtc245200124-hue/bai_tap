# Bài tập xây dựng bố cục với CSS Box Model

Mở `index.html` bằng trình duyệt. Nhấn **F12**, chọn một thẻ `.card` và mở tab **Computed** để xem Box Model.

## Quy tắc áp dụng

Cả ba thẻ có:

```css
width: 280px;
height: 150px;
padding: 20px;
border: 5px solid #3498db;
margin: 20px;
```

Thẻ thứ nhất dùng `box-sizing: content-box` và nền xanh lá. Với cách này, `width` và `height` chỉ tính phần content. Kích thước hộp thực tế không tính margin là:

```text
width: 280 + padding trái/phải 40 + border trái/phải 10 = 330px
height: 150 + padding trên/dưới 40 + border trên/dưới 10 = 200px
```

Hai thẻ còn lại dùng `box-sizing: border-box`, nên padding và border nằm bên trong kích thước đã khai báo 280px × 150px. Chúng có nền vàng và đỏ.

Mở riêng file `style.css` để xem toàn bộ các quy tắc CSS. Đưa cả `index.html` và `style.css` lên GitHub.
