# Thực hành xóa CSDL trên MySQL Workbench

## Cảnh báo quan trọng

`DROP DATABASE` là thao tác phá hủy. Nó xóa database cùng toàn bộ bảng và dữ liệu bên trong. Hãy chắc chắn chọn đúng tên database và sao lưu dữ liệu nếu cần. Project này chỉ cung cấp câu lệnh; không tự động thực thi lệnh xóa.

## Cách 1: Xóa bằng giao diện Workbench

1. Mở MySQL Workbench và đăng nhập vào MySQL Server.
2. Trong khu vực **SCHEMAS**, nhấp chuột phải vào schema:

   ```text
   my_database
   ```

3. Chọn **Drop Schema**.
4. Kiểm tra lại đúng tên schema trong hộp thoại cảnh báo.
5. Chọn **Drop Now** để xác nhận.
6. Nhấn Refresh tại khu vực **SCHEMAS** và kiểm tra database đã biến mất.

## Cách 2: Xóa bằng câu lệnh SQL

1. Mở **New Query Tab**.
2. Mở file `drop_database.sql` hoặc nhập:

```sql
DROP DATABASE IF EXISTS `my_database`;
```

3. Kiểm tra thật kỹ tên database trước khi chạy.
4. Nhấn biểu tượng tia sét **Execute**.
5. Chạy file `verify_drop.sql`:

```sql
SHOW DATABASES LIKE 'my_database';
```

Nếu không có dòng kết quả, database đã được xóa.

## Chạy bằng terminal (tùy chọn)

```bash
mysql -u root -p < drop_database.sql
mysql -u root -p < verify_drop.sql
```

Không đưa mật khẩu MySQL lên GitHub.
