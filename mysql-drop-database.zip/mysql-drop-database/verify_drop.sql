-- Kết quả mong đợi: không có dòng nào được trả về.
SHOW DATABASES LIKE 'my_database';
