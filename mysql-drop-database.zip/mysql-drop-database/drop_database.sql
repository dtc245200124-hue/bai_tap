-- [Thực hành] Xóa CSDL trên MySQL Workbench
-- CẢNH BÁO: Lệnh này xóa database và toàn bộ bảng, dữ liệu bên trong.
-- Hãy kiểm tra đúng tên database trước khi Execute.
DROP DATABASE IF EXISTS `my_database`;
