# User Management JDBC

Ứng dụng Java Web quản lý User theo MVC, sử dụng Servlet, JSP, JSTL, JDBC và MySQL. Phiên bản này hỗ trợ đầy đủ CRUD, tìm kiếm theo `country` và sắp xếp theo `name` tăng dần.

## Chức năng

- Hiển thị danh sách User.
- Thêm, sửa và xoá User.
- Tìm kiếm User theo một phần tên quốc gia.
- Sắp xếp toàn bộ danh sách theo tên tăng dần.

## Khởi tạo MySQL

Chạy file `schema.sql` trong MySQL Workbench, DBeaver hoặc terminal. Script tạo database `demo`, bảng `users` và hai bản ghi mẫu.

## Cấu hình kết nối

Ứng dụng đọc cấu hình từ các biến môi trường sau:

```text
USER_DB_URL=jdbc:mysql://localhost:3306/demo?useSSL=false&serverTimezone=UTC
USER_DB_USERNAME=root
USER_DB_PASSWORD=your-password
```

Nếu không thiết lập biến môi trường, ứng dụng dùng URL database `demo`, username `root` và mật khẩu mặc định `password`. Bạn nên thiết lập biến môi trường trên máy của mình và tuyệt đối không đưa mật khẩu thật lên GitHub.

## Chạy dự án

```bash
mvn clean package
```

Sao chép `target/user-management.war` vào thư mục `webapps` của Tomcat 10.1+, khởi động Tomcat rồi truy cập:

```text
http://localhost:8080/user-management/users
```

## Cấu trúc MVC

`User` là model dữ liệu; `IUserDAO` và `UserDAO` đảm nhiệm truy cập MySQL bằng JDBC; `UserServlet` điều hướng các action; các JSP trong `src/main/webapp/user` là tầng view.
