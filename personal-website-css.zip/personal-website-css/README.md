# Thực hành tạo trang web cá nhân với CSS

Mở file `index.html` bằng trình duyệt để xem trang cá nhân.

Trang gồm tiêu đề chính, ảnh đại diện `avatar.jpg`, phần giới thiệu, danh sách sở thích, mục tiêu học tập và bảng thông tin liên hệ.

File `style.css` minh họa:

- Nhúng CSS ngoài bằng thẻ `link`;
- Bộ chọn phần tử và class;
- `border`, `border-radius` và `box-shadow`;
- `background-color` và `background-image`;
- Màu chữ với `color`;
- Định dạng danh sách và bảng;
- Responsive cơ bản trên màn hình nhỏ.

Đưa toàn bộ thư mục, bao gồm `index.html`, `style.css` và `avatar.jpg`, lên GitHub rồi nộp link repository.
