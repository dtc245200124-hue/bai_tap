# Từ điển Anh - Việt

Ứng dụng mẫu dùng Java 17, JSP và Jakarta Servlet 6.0, tương thích Apache Tomcat 10.1+.

Trang chủ có form tra cứu gửi từ tiếng Anh bằng phương thức POST tới `/translate`. Từ được tra không phân biệt chữ hoa/chữ thường và bỏ khoảng trắng đầu/cuối. Từ điển mẫu gồm: `hello` (Xin chào), `how` (Thế nào), `book` (Quyển sách), `computer` (Máy tính), `student` (Sinh viên), `goodbye` (Tạm biệt), `water` (Nước), và `school` (Trường học). Từ không có trong danh sách sẽ hiển thị thông báo `Không tìm thấy từ: [từ_khóa]`.

## Build

Cần Java 17+ và Maven. Chạy từ thư mục gốc dự án:

```bash
mvn clean package
```

Sau khi Maven báo `BUILD SUCCESS`, WAR được tạo tại `target/jsp-servlet-dictionary.war`.

## Chạy trên Tomcat

Sao chép WAR vào thư mục `webapps` của Tomcat 10.1+ và khởi động máy chủ. Truy cập `http://localhost:8080/jsp-servlet-dictionary/` để tra cứu.
