<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Từ điển Anh - Việt</title>
    <style>
        * { box-sizing: border-box; }
        body { min-height: 100vh; display: grid; place-items: center; margin: 0; padding: 24px; font-family: Arial, sans-serif; background: #f1f5f9; color: #172554; }
        .dictionary-card { width: min(100%, 440px); padding: 34px; background: white; border-radius: 12px; box-shadow: 0 12px 32px rgba(15, 23, 42, .12); }
        h1 { margin: 0 0 8px; text-align: center; font-size: 1.65rem; }
        .intro { margin: 0 0 24px; text-align: center; color: #64748b; }
        label { display: block; margin-bottom: 7px; font-weight: 600; }
        input { width: 100%; padding: 12px; border: 1px solid #cbd5e1; border-radius: 6px; font: inherit; }
        input:focus { outline: 2px solid #93c5fd; border-color: #2563eb; }
        button { width: 100%; margin-top: 16px; padding: 12px; border: 0; border-radius: 6px; background: #1b2a7a; color: white; font: inherit; font-weight: 700; cursor: pointer; }
        button:hover { background: #263aa0; }
    </style>
</head>
<body>
    <main class="dictionary-card">
        <h1>Từ điển Anh - Việt</h1>
        <p class="intro">Nhập một từ tiếng Anh để tra nghĩa tiếng Việt.</p>
        <form action="${pageContext.request.contextPath}/translate" method="POST">
            <label for="word">Từ tiếng Anh</label>
            <input id="word" type="text" name="word" placeholder="Ví dụ: hello" autocomplete="off" required autofocus>
            <button type="submit">Tìm kiếm</button>
        </form>
    </main>
</body>
</html>
