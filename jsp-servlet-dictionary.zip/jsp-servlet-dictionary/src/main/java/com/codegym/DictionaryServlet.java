package com.codegym;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "DictionaryServlet", urlPatterns = "/translate")
public class DictionaryServlet extends HttpServlet {

    private static final Map<String, String> DICTIONARY = Map.of(
            "hello", "Xin chào",
            "how", "Thế nào",
            "book", "Quyển sách",
            "computer", "Máy tính",
            "student", "Sinh viên",
            "goodbye", "Tạm biệt",
            "water", "Nước",
            "school", "Trường học"
    );

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String searchWord = request.getParameter("word");
        String normalizedWord = searchWord == null ? "" : searchWord.trim().toLowerCase(Locale.ROOT);
        String translation = DICTIONARY.get(normalizedWord);

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html lang=\"vi\">");
            out.println("<head>");
            out.println("  <meta charset=\"UTF-8\">");
            out.println("  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
            out.println("  <title>Kết quả tra cứu</title>");
            out.println("  <style>body{font-family:Arial,sans-serif;text-align:center;margin:12vh auto;padding:24px;max-width:720px;background:#f8fafc;color:#172554}.card{padding:32px;background:white;border-radius:12px;box-shadow:0 12px 32px #0f17221f}.translation{color:#15803d;font-size:1.5rem;font-weight:700}.not-found{color:#b91c1c;font-weight:700}a{display:inline-block;margin-top:16px;padding:10px 18px;border-radius:6px;background:#1b2a7a;color:white;text-decoration:none}</style>");
            out.println("</head>");
            out.println("<body><main class=\"card\">");
            out.println("  <h1>Kết quả tra cứu</h1>");

            if (normalizedWord.isBlank()) {
                out.println("  <p class=\"not-found\">Vui lòng nhập từ cần tra cứu.</p>");
            } else if (translation != null) {
                out.println("  <p>Từ tiếng Anh: <strong>" + escapeHtml(searchWord.trim()) + "</strong></p>");
                out.println("  <p class=\"translation\">Nghĩa tiếng Việt: " + escapeHtml(translation) + "</p>");
            } else {
                out.println("  <p class=\"not-found\">Không tìm thấy từ: " + escapeHtml(searchWord.trim()) + "</p>");
            }

            out.println("  <a href=\"" + request.getContextPath() + "/\">Quay lại</a>");
            out.println("</main></body></html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/");
    }

    private static String escapeHtml(String value) {
        return value.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}
