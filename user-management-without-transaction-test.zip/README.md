# User Management JDBC, Stored Procedures và Transaction

Ứng dụng Java Web quản lý User theo MVC, sử dụng Servlet, JSP, JSTL, JDBC và MySQL. Ứng dụng hỗ trợ CRUD, tìm kiếm theo `country`, sắp xếp theo `name`, Stored Procedure và transaction khi thêm User cùng các quyền.

## Bài kiểm thử không dùng transaction

Dự án có thêm phương thức `insertUpdateWithoutTransaction()` trong `UserDAO`. Phương thức này xoá và tạo lại bảng `Employee`, chèn hai nhân viên (`Quynh` và `Ngan`), sau đó cố tình gán sai tham số của câu lệnh cập nhật để phát sinh lỗi. Vì JDBC đang dùng auto-commit mặc định, hai dòng INSERT vẫn được ghi dù câu lệnh UPDATE thất bại.

Chạy kiểm thử bằng URL:

```text
http://localhost:8080/user-management/users?action=test-without-tran
```

Sau đó kiểm tra:

```sql
SELECT * FROM Employee;
```

Bài kiểm thử này nhằm minh hoạ dữ liệu ghi dở khi không dùng transaction. Không sử dụng route này trong môi trường production.

## Transaction thêm User và quyền

Form thêm User cho phép chọn nhiều quyền. `UserDAO.addUserTransaction()` tắt auto-commit, thêm User với generated key, thêm các cặp `user_id`/`permission_id`, rồi `commit()`. Nếu bất kỳ bước nào lỗi, phương thức gọi `rollback()` để không để lại dữ liệu dở.

## Khởi tạo MySQL

Chạy toàn bộ file `schema.sql` trong MySQL Workbench, DBeaver hoặc terminal. Script tạo database `demo`, các bảng `users`, `permission`, `user_permission`, `Employee`, dữ liệu mẫu và Stored Procedure của các bài trước.

## Cấu hình kết nối

Thiết lập các biến môi trường sau trước khi chạy Tomcat:

```text
USER_DB_URL=jdbc:mysql://localhost:3306/demo?useSSL=false&serverTimezone=UTC
USER_DB_USERNAME=root
USER_DB_PASSWORD=your-password
```

Không đưa mật khẩu thật lên GitHub.

## Chạy dự án

```bash
mvn clean package
```

Sao chép `target/user-management.war` vào thư mục `webapps` của Tomcat 10.1+, khởi động Tomcat rồi truy cập:

```text
http://localhost:8080/user-management/users
```
