# Thực hành bảng trong CSS

Mở `index.html` bằng trình duyệt để xem bảng sản phẩm.

File `style.css` minh họa các thuộc tính:

- `border` tạo đường viền cho bảng, hàng tiêu đề và ô dữ liệu;
- `border-collapse: collapse` gộp đường viền thành một đường;
- `width` và `height` thiết lập kích thước bảng;
- `text-align` căn trái, giữa hoặc phải theo chiều ngang;
- `vertical-align` căn giữa theo chiều dọc;
- `padding` tạo khoảng cách giữa viền và nội dung;
- `background`, `color` và màu viền tạo giao diện cho bảng;
- Hiệu ứng xen kẽ hàng và hover giúp bảng dễ đọc hơn.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
