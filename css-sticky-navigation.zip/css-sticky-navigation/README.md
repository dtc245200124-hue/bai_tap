# Thực hành tạo thanh điều hướng sticky

Mở file `index.html` bằng trình duyệt và cuộn trang xuống. Thanh menu sẽ dính trên đầu màn hình nhờ:

```css
.sticky-menu {
    position: sticky;
    top: 0;
}
```

Trang gồm bốn section có liên kết neo: Trang chủ, Giới thiệu, Dịch vụ và Liên hệ. Mỗi section có chiều cao lớn để dễ quan sát hiệu ứng sticky.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
