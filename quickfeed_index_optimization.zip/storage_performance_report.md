# Báo cáo tối ưu chỉ mục QuickFeed

## Kết luận

Bảng `Posts` đang bị **over-indexing**: ngoài khóa chính, hệ thống có thêm năm chỉ mục. Mỗi lần `INSERT`, InnoDB phải ghi dữ liệu mới và duy trì từng cây B-Tree liên quan. Vì vậy, thao tác ghi có thể chậm và chi phí lưu trữ tăng theo số lượng chỉ mục. Giải pháp là giữ lại `idx_user_id` và `idx_created_at`, đồng thời xóa `idx_content`, `idx_post_type` và `idx_is_visible`.

`idx_content` là chỉ mục prefix trên cột `TEXT`, nên có thể chiếm nhiều trang index nhưng không phù hợp cho tìm kiếm ngữ nghĩa trong nội dung. Nếu cần tìm từ khóa, `FULLTEXT` là hướng phù hợp hơn. `post_type` chỉ có khoảng ba giá trị, còn `is_visible` chỉ có hai giá trị. Hai cột này có **cardinality** thấp. Khi một giá trị xuất hiện ở phần lớn số dòng, trình tối ưu thường thấy quét bảng rẻ hơn việc dò chỉ mục rồi đọc lại nhiều dòng.

Script ghi nhận `DATA_LENGTH` và `INDEX_LENGTH` trước và sau khi dọn dẹp thông qua `information_schema.TABLES`. Trên dữ liệu thực tế, `INDEX_LENGTH` phải giảm sau khi ba chỉ mục bị loại bỏ. Không có số đo chạy thật trong môi trường này, vì vậy báo cáo không đặt số MB giả định. Kết quả cần nộp là hai ảnh chụp hoặc hai dòng kết quả trước/sau khi chạy script.

Việc cắt bỏ ba chỉ mục giúp mỗi lần đăng bài giảm ba cấu trúc B-Tree phải cập nhật. Đổi lại, một số truy vấn lọc theo `post_type`, `is_visible` hoặc `content` có thể không còn dùng index. Đây là đánh đổi hợp lý vì các chỉ mục đó có độ chọn lọc thấp hoặc chi phí lưu trữ cao.

## Bảng quyết định

| Chỉ mục | Quyết định | Lý do |
|---|---|---|
| `idx_user_id` | Giữ lại | Hỗ trợ tải bài viết theo người dùng; độ phân biệt thường cao. |
| `idx_content` | Xóa | Prefix B-Tree trên `TEXT` tốn dung lượng; cân nhắc `FULLTEXT`. |
| `idx_post_type` | Xóa | Chỉ khoảng ba giá trị, cardinality thấp. |
| `idx_is_visible` | Xóa | Boolean chỉ có hai giá trị, độ chọn lọc thường thấp. |
| `idx_created_at` | Giữ lại | Hỗ trợ newsfeed sắp xếp theo thời gian mới nhất. |

## Cách đối chiếu

Chạy `quickfeed_index_optimization.sql`. So sánh `index_size_mb` và `total_size_mb` trước với sau khi chạy ba lệnh `DROP INDEX`. Sau đó dùng `SHOW INDEX FROM Posts` để xác nhận chỉ còn các chỉ mục cần thiết.

## References

[1]: https://dev.mysql.com/doc/refman/8.0/en/innodb-index-types.html "MySQL 8.0 Reference Manual: InnoDB Index Types"

[2]: https://dev.mysql.com/doc/refman/8.0/en/optimization-indexes.html "MySQL 8.0 Reference Manual: Optimization and Indexes"

[3]: https://dev.mysql.com/doc/refman/8.0/en/fulltext-search.html "MySQL 8.0 Reference Manual: Full-Text Search Functions"

[4]: https://dev.mysql.com/doc/refman/8.0/en/information-schema-tables-table.html "MySQL 8.0 Reference Manual: The INFORMATION_SCHEMA TABLES Table"
