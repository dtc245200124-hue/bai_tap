# AI Prompt Log — QuickFeed Index Optimization

## Prompt 1: Cardinality và chỉ mục độ phân giải thấp

**Câu hỏi đã sử dụng:**

> Trong MySQL, cardinality của một cột là gì? Vì sao các cột Boolean như `is_visible` hoặc cột trạng thái chỉ có vài giá trị thường là ứng cử viên kém cho B-Tree index?

**Tóm tắt kết quả:**

Cardinality là số lượng giá trị khác nhau mà một cột có. Cardinality càng cao thì một điều kiện lọc thường loại bỏ được càng nhiều dòng, nên chỉ mục có khả năng hữu ích hơn. Với `is_visible`, chỉ có hai giá trị `0` và `1`. Với `post_type`, chỉ có khoảng ba giá trị. Nếu một giá trị chiếm phần lớn bảng, truy vấn dùng index vẫn phải đọc rất nhiều dòng. Khi đó, full table scan có thể rẻ hơn việc đọc index rồi truy cập các trang dữ liệu tương ứng. Quyết định cuối cùng vẫn phụ thuộc vào phân bố dữ liệu và kế hoạch `EXPLAIN`, không chỉ dựa vào kiểu dữ liệu.

## Prompt 2: Chi phí của index trên TEXT

**Câu hỏi đã sử dụng:**

> Nếu tạo B-Tree prefix index trên cột `TEXT` dài và tạo index trên cột Boolean, các chỉ mục này ảnh hưởng thế nào đến RAM, disk và thao tác INSERT trong MySQL?

**Tóm tắt kết quả:**

Prefix index trên `TEXT` lưu phần tiền tố của mỗi dòng trong cấu trúc chỉ mục. Prefix càng dài thì index page và bộ nhớ đệm cần thiết càng lớn. Mỗi lần `INSERT`, `UPDATE` hoặc `DELETE`, MySQL phải duy trì thêm cấu trúc index, làm tăng I/O và chi phí ghi. Boolean index thường nhỏ hơn index trên nội dung dài nhưng có thể ít giá trị do cardinality thấp. Việc dùng index cần được quyết định theo truy vấn thực tế và `EXPLAIN`.

## Prompt 3: Tìm kiếm văn bản

**Câu hỏi đã sử dụng:**

> Muốn tìm từ khóa trong cột `content` kiểu `TEXT` mà không lạm dụng B-Tree prefix index thì nên dùng cơ chế nào của MySQL?

**Tóm tắt kết quả:**

Nếu nghiệp vụ cần tìm từ hoặc cụm từ trong văn bản, nên đánh giá `FULLTEXT INDEX` và các câu lệnh `MATCH ... AGAINST`. FULLTEXT được thiết kế cho tìm kiếm văn bản, khác với B-Tree vốn phù hợp hơn cho so sánh bằng, khoảng giá trị và sắp xếp. Cần kiểm tra ngôn ngữ, stopword, độ dài từ tối thiểu và nhu cầu tìm kiếm trước khi triển khai.

## Prompt 4: Kế hoạch kiểm chứng

**Câu hỏi đã sử dụng:**

> Hãy đề xuất cách so sánh dung lượng chỉ mục trước và sau khi xóa các index dư thừa trong bảng `Posts`.

**Tóm tắt kết quả:**

Ghi nhận `INDEX_LENGTH` bằng `SHOW TABLE STATUS LIKE 'Posts'` hoặc đọc `INDEX_LENGTH` từ `information_schema.TABLES`. Sau khi xóa đúng ba index, chạy `ANALYZE TABLE Posts`, rồi truy vấn lại cùng các cột. Dùng `SHOW INDEX FROM Posts` để xác nhận cấu trúc và dùng `EXPLAIN` để kiểm tra các truy vấn quan trọng. Không được tự động xóa toàn bộ index vì khóa chính và các index phục vụ nghiệp vụ vẫn cần được giữ lại.

## Nhận xét cá nhân

Kết quả AI được dùng để hiểu khái niệm và thiết kế cách đo. Quyết định triển khai cuối cùng là giữ `idx_user_id` và `idx_created_at`, xóa đúng `idx_content`, `idx_post_type` và `idx_is_visible`. Cần đo trên dữ liệu thực tế trước khi kết luận mức giảm dung lượng cụ thể.
