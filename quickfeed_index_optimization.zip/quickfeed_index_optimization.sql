-- QuickFeed: tối ưu hóa chỉ mục cho bảng Posts
-- Giữ lại: idx_user_id, idx_created_at
-- Loại bỏ: idx_content, idx_post_type, idx_is_visible

CREATE DATABASE IF NOT EXISTS quickfeed_db;
USE quickfeed_db;

-- Dùng đoạn khởi tạo dưới đây nếu bảng Posts chưa tồn tại.
-- CREATE TABLE Posts (
--     post_id INT AUTO_INCREMENT PRIMARY KEY,
--     user_id INT NOT NULL,
--     content TEXT,
--     post_type VARCHAR(10),
--     is_visible BOOLEAN DEFAULT 1,
--     created_at DATETIME DEFAULT CURRENT_TIMESTAMP
-- );

-- ============================================================
-- 1. Ghi nhận hiện trạng trước khi tối ưu
-- ============================================================
SHOW TABLE STATUS LIKE 'Posts';

SELECT
    TABLE_NAME,
    ROUND(DATA_LENGTH / 1024 / 1024, 2) AS data_size_mb,
    ROUND(INDEX_LENGTH / 1024 / 1024, 2) AS index_size_mb,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS total_size_mb,
    TABLE_ROWS AS estimated_rows
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'Posts';

SHOW INDEX FROM Posts;

-- ============================================================
-- 2. Xóa đúng 3 chỉ mục có giá trị thấp hoặc chi phí cao
-- ============================================================
-- idx_content: prefix B-Tree trên TEXT gây overhead lớn; dùng
-- FULLTEXT phù hợp hơn nếu nhu cầu là tìm kiếm nội dung.
ALTER TABLE Posts DROP INDEX idx_content;

-- idx_post_type: chỉ có khoảng 3 giá trị nên cardinality thấp.
ALTER TABLE Posts DROP INDEX idx_post_type;

-- idx_is_visible: chỉ có hai giá trị 0/1; thường không đủ
-- chọn lọc để B-Tree đem lại lợi ích đáng kể.
ALTER TABLE Posts DROP INDEX idx_is_visible;

-- Không xóa các chỉ mục có giá trị:
-- idx_user_id: hỗ trợ lọc bài viết theo người dùng.
-- idx_created_at: hỗ trợ truy vấn newsfeed theo thời gian.

-- Cập nhật thống kê để Query Optimizer có thông tin mới.
ANALYZE TABLE Posts;

-- ============================================================
-- 3. Đối chiếu sau khi tối ưu
-- ============================================================
SHOW TABLE STATUS LIKE 'Posts';

SELECT
    TABLE_NAME,
    ROUND(DATA_LENGTH / 1024 / 1024, 2) AS data_size_mb,
    ROUND(INDEX_LENGTH / 1024 / 1024, 2) AS index_size_mb,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS total_size_mb,
    TABLE_ROWS AS estimated_rows
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'Posts';

SHOW INDEX FROM Posts;

-- Kiểm tra hai chỉ mục được giữ lại.
EXPLAIN SELECT * FROM Posts WHERE user_id = 1;
EXPLAIN SELECT * FROM Posts ORDER BY created_at DESC LIMIT 20;

-- Nếu cần tìm từ khóa trong content, cân nhắc FULLTEXT thay vì
-- B-Tree prefix index. Chỉ chạy khi nghiệp vụ thực sự cần:
-- ALTER TABLE Posts ADD FULLTEXT INDEX ft_content (content);
