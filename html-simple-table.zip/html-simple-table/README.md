# Thực hành tạo bảng đơn giản trong HTML

Mở file `index.html` bằng trình duyệt để xem kết quả.

Bảng sử dụng:

- `<table border="1">` để tạo bảng có đường viền;
- `<tr>` để tạo các hàng;
- `<th>` cho tiêu đề cột;
- `<td>` cho dữ liệu.

Bảng có các cột **Họ và Tên**, **Tuổi**, **Lớp** và ba học sinh mẫu.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
