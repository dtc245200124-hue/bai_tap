# Git command reference

| Lệnh | Ý nghĩa |
|---|---|
| `git init -b main` | Khởi tạo Local Repository và nhánh `main` |
| `git status` | Xem trạng thái file và staging area |
| `git remote add origin URL` | Liên kết repository local với remote GitHub |
| `git remote -v` | Xem các URL remote |
| `git add README.md` | Đưa README vào staging area |
| `git add .` | Đưa mọi thay đổi vào staging area |
| `git commit -m "message"` | Lưu thay đổi vào lịch sử Git |
| `git push -u origin main` | Đẩy commit lên GitHub và thiết lập upstream |
