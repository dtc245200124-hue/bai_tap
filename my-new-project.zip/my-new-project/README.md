# my-new-project

Repository thực hành quy trình làm việc cơ bản với Git và GitHub.

## Mục tiêu

- Khởi tạo Local Repository bằng `git init`;
- Liên kết Local Repository với Remote Repository trên GitHub;
- Đưa file vào staging area bằng `git add`;
- Lưu thay đổi bằng `git commit`;
- Đồng bộ mã nguồn lên GitHub bằng `git push`.

## Ý nghĩa các câu lệnh Git

### 1. Khởi tạo Local Repository

```bash
git init -b main
```

Tạo thư mục `.git` và biến thư mục hiện tại thành một Git repository. Tùy chọn `-b main` đặt tên nhánh mặc định là `main`.

### 2. Kiểm tra trạng thái

```bash
git status
```

Hiển thị các file chưa được theo dõi, file đã thay đổi và trạng thái staging area.

### 3. Kết nối Remote Repository

Thay `<username>` bằng tên tài khoản GitHub thật:

```bash
git remote add origin https://github.com/<username>/my-new-project.git
```

Tạo remote có tên `origin` trỏ tới repository trên GitHub. `origin` là tên quy ước cho remote chính.

Kiểm tra remote:

```bash
git remote -v
```

### 4. Đưa file vào staging area

```bash
git add README.md
```

Đưa `README.md` vào vùng staging để chuẩn bị cho commit. Có thể dùng `git add .` để thêm tất cả file trong thư mục hiện tại.

### 5. Tạo commit

```bash
git commit -m "Add README.md file"
```

Lưu một phiên bản thay đổi vào lịch sử Git. Tùy chọn `-m` ghi thông điệp mô tả nội dung commit.

### 6. Đẩy code lên GitHub

```bash
git push -u origin main
```

Đẩy các commit của nhánh local `main` lên nhánh `main` trên remote `origin`. Tùy chọn `-u` thiết lập liên kết upstream để những lần sau chỉ cần dùng `git push`.

> Một số tài liệu cũ dùng `git push origin master`. Project này dùng nhánh hiện đại `main`, vì vậy cần push `main`.

## Các bước thực hiện đầy đủ

1. Trên GitHub, chọn **New repository**.
2. Đặt tên repository là `my-new-project`.
3. Không cần tạo sẵn README trên GitHub để tránh xung đột với README local.
4. Tại thư mục project, chạy:

```bash
git remote add origin https://github.com/<username>/my-new-project.git
git add README.md
git commit -m "Add README.md file"
git push -u origin main
```

Sau đó mở URL:

```text
https://github.com/<username>/my-new-project
```

và copy URL đó để nộp bài.
