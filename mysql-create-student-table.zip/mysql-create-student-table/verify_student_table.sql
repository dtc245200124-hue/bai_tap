USE `demo`;

-- Xem danh sách bảng trong database demo.
SHOW TABLES;

-- Kiểm tra các cột của bảng Student.
DESCRIBE `Student`;
