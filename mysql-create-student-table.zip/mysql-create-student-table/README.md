# Thực hành tạo bảng Student trên MySQL Workbench

## Yêu cầu

- Tạo database tên `demo`.
- Tạo bảng `Student` gồm các trường:
  - `id` kiểu `INT`;
  - `name` kiểu `VARCHAR(200)`;
  - `age` kiểu `INT`;
  - `country` kiểu `VARCHAR(50)`.

## Thực hiện trên MySQL Workbench

1. Mở MySQL Workbench và đăng nhập MySQL Server.
2. Mở **New Query Tab**.
3. Mở file `create_student_table.sql` hoặc nhập:

```sql
CREATE DATABASE IF NOT EXISTS `demo`;
USE `demo`;

CREATE TABLE IF NOT EXISTS `Student` (
    `id` INT,
    `name` VARCHAR(200),
    `age` INT,
    `country` VARCHAR(50)
);
```

4. Nhấn biểu tượng tia sét **Execute** để chạy các câu lệnh.
5. Refresh khu vực **SCHEMAS**, mở database `demo` → **Tables** để thấy bảng `Student`.
6. Chạy file `verify_student_table.sql` để kiểm tra:

```sql
USE `demo`;
SHOW TABLES;
DESCRIBE `Student`;
```

## Chạy bằng terminal (tùy chọn)

```bash
mysql -u root -p < create_student_table.sql
mysql -u root -p < verify_student_table.sql
```

Không đưa mật khẩu MySQL lên GitHub.
