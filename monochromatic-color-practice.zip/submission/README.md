# Thực hành phối màu đơn tông

Dự án được xây dựng từ mã nguồn mẫu `Pra.zip` của CodeGym.

## Phiên bản 1: Blue Mono

Màu chủ đạo: `#00ADEE`.

- Banner: `#00BFF2`
- Nhãn ON SALE/PREVIEW: `#00B2EF`
- Nền nội dung: `#8DD7F7`
- Nền footer: `#C6E9FA`
- Chữ: đen hoặc trắng tùy độ tương phản

Mở file `blue-mono/index.html` trong trình duyệt.

## Phiên bản 2: Purple Mono

Bảng đơn tông mở rộng để thực hiện bước 8 của bài tập:

- Màu chính: `#7C3AED`
- Bậc 2: `#8447EE`
- Bậc 3: `#9565F2`
- Bậc 4: `#CDB5FA`
- Bậc 5: `#EDE5FE`

Mở file `purple-mono/index.html` trong trình duyệt.

## Nộp bài

Có thể đưa thư mục `submission` lên GitHub hoặc dùng một trong hai file `index.html` trên CodePen. Các thư mục đều chứa ảnh, font và CSS cần thiết từ mã nguồn mẫu.
