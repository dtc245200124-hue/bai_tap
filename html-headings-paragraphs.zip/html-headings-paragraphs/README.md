# Bài tập sử dụng thẻ tiêu đề và đoạn văn

Mở file `index.html` bằng trình duyệt để xem kết quả.

Trang sử dụng:

- Thẻ `<h1>` với nội dung **Chào mừng đến với trang web của tôi**;
- Thẻ `<h2>` với nội dung **Giới thiệu bản thân**;
- Hai thẻ `<p>` mô tả sở thích và mục tiêu học lập trình.

Đưa file này lên GitHub và nộp link repository.
