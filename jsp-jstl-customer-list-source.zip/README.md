# JSP JSTL Customer List

Ứng dụng Maven Webapp hiển thị danh sách khách hàng bằng **JSTL** và JSP Expression Language, tương thích Apache Tomcat 10.1+.

## Yêu cầu

- JDK 17+
- Maven 3.8+
- Apache Tomcat 10.1+

## Chạy dự án

Từ thư mục gốc, chạy:

```bash
mvn clean package
```

Sau đó sao chép `target/jsp-jstl-customer-list.war` vào thư mục `webapps` của Tomcat và truy cập:

```text
http://localhost:8080/jsp-jstl-customer-list/
```

## JSTL trên Tomcat 10+

Dự án dùng Jakarta JSTL 3.0.1 với URI:

```jsp
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
```

Tomcat 10+ sử dụng namespace `jakarta`. URI cũ `http://java.sun.com/jsp/jstl/core` thường dùng cho JSTL phiên bản `javax` trên Tomcat 9 trở về trước.
