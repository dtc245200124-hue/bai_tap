<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.Arrays" %>
<%@ page import="java.util.LinkedHashMap" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%
    Map<String, String> customer1 = new LinkedHashMap<>();
    customer1.put("name", "Nguyễn Văn An");
    customer1.put("birthday", "1990-05-15");
    customer1.put("address", "Hà Nội");
    customer1.put("image", "images/customer-1.svg");

    Map<String, String> customer2 = new LinkedHashMap<>();
    customer2.put("name", "Trần Thị Bình");
    customer2.put("birthday", "1993-08-22");
    customer2.put("address", "Đà Nẵng");
    customer2.put("image", "images/customer-2.svg");

    Map<String, String> customer3 = new LinkedHashMap<>();
    customer3.put("name", "Lê Minh Cường");
    customer3.put("birthday", "1988-11-03");
    customer3.put("address", "Thành phố Hồ Chí Minh");
    customer3.put("image", "images/customer-3.svg");

    List<Map<String, String>> customers = Arrays.asList(customer1, customer2, customer3);
    request.setAttribute("customers", customers);
%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách khách hàng</title>
    <style>
        :root { --primary: #2563eb; --dark: #0f172a; --muted: #64748b; --background: #f1f5f9; }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; padding: 48px 20px; font-family: Arial, sans-serif; background: var(--background); color: var(--dark); }
        .page { width: min(100%, 1080px); margin: auto; }
        .heading { margin-bottom: 28px; text-align: center; }
        h1 { margin: 0 0 8px; color: var(--primary); font-size: 32px; }
        .subtitle { margin: 0; color: var(--muted); }
        .customer-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 22px; }
        .customer-card { overflow: hidden; border-radius: 14px; background: #fff; box-shadow: 0 7px 20px rgba(15, 23, 42, .08); transition: transform .2s, box-shadow .2s; }
        .customer-card:hover { transform: translateY(-4px); box-shadow: 0 12px 28px rgba(15, 23, 42, .14); }
        .customer-image { width: 100%; height: 210px; display: block; object-fit: cover; background: #dbeafe; }
        .customer-info { padding: 20px; }
        .customer-name { margin: 0 0 16px; color: var(--primary); font-size: 21px; }
        .detail { display: flex; gap: 8px; margin: 10px 0; color: #334155; line-height: 1.45; }
        .detail-label { min-width: 82px; color: var(--muted); font-weight: 700; }
        .empty { padding: 32px; border-radius: 10px; background: #fff; color: var(--muted); text-align: center; }
    </style>
</head>
<body>
<main class="page">
    <header class="heading">
        <h1>Danh sách khách hàng</h1>
        <p class="subtitle">Thông tin khách hàng được hiển thị bằng JSTL</p>
    </header>

    <section class="customer-grid">
        <c:forEach var="customer" items="${customers}">
            <article class="customer-card">
                <img class="customer-image" src="${customer.image}" alt="Ảnh của ${customer.name}">
                <div class="customer-info">
                    <h2 class="customer-name">${customer.name}</h2>
                    <p class="detail"><span class="detail-label">Ngày sinh:</span><span>${customer.birthday}</span></p>
                    <p class="detail"><span class="detail-label">Địa chỉ:</span><span>${customer.address}</span></p>
                </div>
            </article>
        </c:forEach>
        <c:if test="${empty customers}">
            <p class="empty">Chưa có thông tin khách hàng.</p>
        </c:if>
    </section>
</main>
</body>
</html>
