# AI Prompt Log — MetricsHub

## Prompt 1 — Phân tích công cụ dàn trang

**Câu hỏi:** Khi một phần tử cần chiếm hai hàng và hai cột giữa các phần tử nhỏ, nên dùng CSS Grid hay Flexbox?

**Kết luận áp dụng:** Chọn CSS Grid vì Grid quản lý đồng thời hàng và cột. Flexbox chỉ tối ưu một trục tại một thời điểm, nên yêu cầu `span 2` sẽ cần thêm các lớp lồng nhau hoặc kích thước cố định.

## Prompt 2 — Tái cấu trúc Navbar

**Câu hỏi:** Làm thế nào để Navbar không vỡ khi nhãn ngôn ngữ thay đổi sang tiếng Đức?

**Kết luận áp dụng:** Dùng Flexbox với `gap`, `justify-content: space-between`, `flex: 1` cho vùng liên kết và `white-space: nowrap` cho các mục ngắn. Ở màn hình hẹp, cho vùng liên kết cuộn ngang thay vì đặt các cột pixel cố định.

## Prompt 3 — So sánh Bootstrap breakpoints

**Câu hỏi:** Khác biệt giữa `col-sm-4` và `col-md-4` là gì?

**Kết luận áp dụng:** Cả hai đều chia ba cột từ breakpoint tương ứng trở lên. `col-md-4` giữ một cột trên thiết bị nhỏ hơn `md`, vì vậy phù hợp với yêu cầu Pricing xếp dọc trên mobile và chia ba trên desktop.

## Prompt 4 — Kiểm thử responsive

**Câu hỏi:** Cần kiểm tra gì ở các kích thước desktop, tablet và mobile?

**Kết luận áp dụng:** Desktop hiển thị Grid ba cột và Pricing ba cột. Tablet chuyển Dashboard thành hai cột. Mobile chuyển Dashboard thành một cột, Navbar cho phép xuống hàng và Pricing dùng `col-12`.

## Prompt 5 — Kỹ thuật kết hợp

**Câu hỏi:** Flexbox và Grid có thể kết hợp trong cùng một giao diện không?

**Kết luận áp dụng:** Có. Trong bài này, Grid tạo cấu trúc tổng thể cho Dashboard; bên trong widget dùng Flexbox để căn header, legend và các hoạt động. Bootstrap Grid cũng dựa trên Flexbox để chuẩn hóa Pricing.

## References

[1]: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_flexible_box_layout "MDN CSS flexible box layout"
[2]: https://getbootstrap.com/docs/5.3/layout/grid/ "Bootstrap 5.3 Grid system"
