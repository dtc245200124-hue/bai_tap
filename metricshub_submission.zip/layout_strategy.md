# Layout Strategy — MetricsHub

MetricsHub dùng **Flexbox cho Navbar** vì đây là bố cục một chiều. `justify-content: space-between`, `gap` và `flex-wrap` cho phép logo, menu và hồ sơ tự co giãn theo nội dung, kể cả khi nhãn ngôn ngữ dài.

Dashboard dùng **CSS Grid** vì các widget tạo thành bố cục hai chiều. `.dashboard-grid` có ba cột; biểu đồ doanh thu dùng `grid-column: span 2` và `grid-row: span 2`, còn các widget nhỏ lấp đầy không gian còn lại. Cấu trúc widget là các phần tử anh em trực tiếp, không cần `.column` lồng nhau.

Pricing dùng **Bootstrap Grid** với `row` và `col-12 col-md-4`. Mỗi thẻ chiếm toàn bộ hàng trên mobile và một phần ba hàng từ breakpoint `md` trở lên. Đây là lựa chọn phù hợp cho một lưới chuẩn hóa, giảm CSS tùy biến.

## References

[1]: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout "MDN CSS grid layout"
