# User Management JDBC, Stored Procedures và Transaction

Ứng dụng Java Web quản lý User theo MVC, sử dụng Servlet, JSP, JSTL, JDBC và MySQL. Ứng dụng hỗ trợ CRUD, tìm kiếm theo `country`, sắp xếp theo `name`, Stored Procedure và transaction khi thêm User cùng các quyền.

## Chức năng transaction

Form thêm User cho phép chọn nhiều quyền: Thêm, Sửa, Xoá và Xem. `UserDAO.addUserTransaction()` tắt auto-commit, thêm bản ghi vào `users` với `RETURN_GENERATED_KEYS`, thêm các cặp `user_id`/`permission_id` vào `user_permission`, rồi gọi `commit()`. Nếu bất kỳ bước nào lỗi, phương thức gọi `rollback()` để không để lại User đã tạo dở.

## Khởi tạo MySQL

Chạy toàn bộ file `schema.sql` trong MySQL Workbench, DBeaver hoặc terminal. Script tạo database `demo`, bảng `users`, `permission`, `user_permission`, dữ liệu mẫu và các Stored Procedure của bài trước.

## Cấu hình kết nối

Thiết lập các biến môi trường sau trước khi chạy Tomcat:

```text
USER_DB_URL=jdbc:mysql://localhost:3306/demo?useSSL=false&serverTimezone=UTC
USER_DB_USERNAME=root
USER_DB_PASSWORD=your-password
```

Không đưa mật khẩu thật lên GitHub.

## Chạy dự án

```bash
mvn clean package
```

Sao chép `target/user-management.war` vào thư mục `webapps` của Tomcat 10.1+, khởi động Tomcat rồi truy cập:

```text
http://localhost:8080/user-management/users
```

Để kiểm tra thêm User cùng quyền, mở:

```text
http://localhost:8080/user-management/users?action=create
```
