# Thực hành quản lý nội dung bị tràn với Overflow

Mở `index.html` bằng trình duyệt để xem kết quả.

Khối `.overflow-box` có kích thước cố định:

```css
width: 300px;
height: 100px;
background-color: lightgray;
padding: 10px;
overflow: auto;
```

Vì nội dung dài hơn kích thước khối, trình duyệt sẽ tự động hiển thị thanh cuộn khi cần thiết. Kéo thanh cuộn bên trong khối để đọc toàn bộ nội dung.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
