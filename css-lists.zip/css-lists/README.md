# Thực hành danh sách trong CSS

Mở `index.html` bằng trình duyệt để xem các ví dụ.

Trang minh họa:

- `list-style-type`: dấu tròn và số La Mã;
- `list-style-image`: dùng file `bullet.svg` làm hình ảnh đánh dấu;
- `list-style-position`: so sánh `inside` và `outside`;
- `list-style`: thuộc tính rút gọn;
- Màu sắc trên danh sách và phần tử `li`.

CSS nằm trong file `style.css`, còn hình ảnh đánh dấu nằm trong `bullet.svg`.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
