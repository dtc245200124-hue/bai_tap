# Bài tập tạo liên kết trong HTML

Mở `index.html` bằng trình duyệt để kiểm tra các liên kết.

Trang đã có:

- Ba liên kết đến các website khác nhau: Google, Wikipedia và GitHub;
- Liên kết GitHub sử dụng `target="_blank"` để mở trong tab mới;
- Liên kết nội bộ đến `about.html`;
- Liên kết email sử dụng `mailto:student@example.com`;
- Trang `about.html` có liên kết quay về `index.html`.

Đưa toàn bộ thư mục lên GitHub và nộp link repository.
