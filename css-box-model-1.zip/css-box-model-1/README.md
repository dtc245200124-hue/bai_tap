# Thực hành sử dụng Box Model 1

Mở file `index.html` bằng trình duyệt để xem kết quả.

Phần tử `div` sử dụng các giá trị:

```css
margin: 25px;
padding: 35px;
width: 200px;
background-color: lightseagreen;
border: 20px dashed indianred;
```

Theo cách tính trong bài, tổng chiều rộng gồm cả margin là:

```text
width + padding trái/phải + border trái/phải + margin trái/phải
= 200 + (35 + 35) + (20 + 20) + (25 + 25)
= 360px
```

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
