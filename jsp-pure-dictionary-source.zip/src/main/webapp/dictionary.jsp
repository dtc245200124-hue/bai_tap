<%@ page import="java.util.HashMap" %>
<%@ page import="java.util.Map" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%!
    private String escapeHtml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
%>
<%
    request.setCharacterEncoding("UTF-8");
    String searchWord = request.getParameter("search");
    String normalizedWord = searchWord == null ? "" : searchWord.trim().toLowerCase();

    Map<String, String> dictionary = new HashMap<>();
    dictionary.put("hello", "Xin chào");
    dictionary.put("how", "Thế nào");
    dictionary.put("book", "Quyển sách");
    dictionary.put("computer", "Máy tính");
    dictionary.put("student", "Sinh viên");
    dictionary.put("school", "Trường học");
    dictionary.put("apple", "Quả táo");

    String result = dictionary.get(normalizedWord);
    boolean found = result != null;
%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kết quả tra cứu</title>
    <style>
        :root { --primary: #1b2a7a; --background: #f8fafc; }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px; font-family: Arial, sans-serif; background: var(--background); }
        .result-container { width: min(100%, 480px); padding: 36px; border-radius: 14px; background: #fff; box-shadow: 0 8px 24px rgba(0, 0, 0, .12); text-align: center; }
        h1 { margin: 0 0 24px; color: var(--primary); font-size: 26px; }
        .word { color: var(--primary); font-weight: 700; }
        .success, .not-found { margin: 22px 0; padding: 20px; border-radius: 9px; }
        .success { background: #e8f5e9; color: #16803c; }
        .not-found { background: #ffebee; color: #b42318; }
        .meaning { margin: 8px 0 0; font-size: 24px; font-weight: 700; }
        .back-btn { display: inline-block; margin-top: 4px; padding: 11px 20px; border-radius: 7px; background: var(--primary); color: #fff; text-decoration: none; font-weight: 700; }
        .back-btn:hover { background: #121c54; }
    </style>
</head>
<body>
<main class="result-container">
    <h1>Kết quả tra cứu</h1>
    <% if (found) { %>
        <p>Từ cần tra: <span class="word"><%= escapeHtml(searchWord) %></span></p>
        <div class="success">
            <div>Nghĩa tiếng Việt:</div>
            <div class="meaning"><%= escapeHtml(result) %></div>
        </div>
    <% } else { %>
        <div class="not-found">
            <strong>Không tìm thấy!</strong>
            <p>Từ khóa <strong><%= escapeHtml(searchWord) %></strong> chưa có trong từ điển.</p>
        </div>
    <% } %>
    <a href="index.jsp" class="back-btn">Tra từ khác</a>
</main>
</body>
</html>
