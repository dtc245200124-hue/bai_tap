<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Từ điển Anh - Việt</title>
    <style>
        :root { --primary: #1b2a7a; --background: #f8fafc; }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px; font-family: Arial, sans-serif; background: var(--background); }
        .dictionary-container { width: min(100%, 420px); padding: 36px; border-radius: 14px; background: #fff; box-shadow: 0 8px 24px rgba(0, 0, 0, .12); text-align: center; }
        h1 { margin: 0 0 10px; color: var(--primary); font-size: 27px; }
        p { color: #64748b; }
        input { width: 100%; margin: 20px 0 12px; padding: 13px 14px; border: 1px solid #cbd5e1; border-radius: 7px; font-size: 16px; }
        input:focus { outline: 2px solid #93c5fd; border-color: #2563eb; }
        button { width: 100%; padding: 13px 20px; border: 0; border-radius: 7px; background: var(--primary); color: #fff; font-size: 16px; font-weight: 700; cursor: pointer; }
        button:hover { background: #121c54; }
    </style>
</head>
<body>
<main class="dictionary-container">
    <h1>Từ điển Anh - Việt</h1>
    <p>Nhập một từ tiếng Anh để tra nghĩa</p>
    <form action="dictionary.jsp" method="post">
        <input type="text" name="search" placeholder="Ví dụ: hello" required autofocus>
        <button type="submit">Tìm kiếm</button>
    </form>
</main>
</body>
</html>
