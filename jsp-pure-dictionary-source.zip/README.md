# JSP Pure Dictionary

Ứng dụng Maven Webapp tra cứu từ Anh–Việt bằng JSP Scriptlet, `Map` và JSP Expression, tương thích với Apache Tomcat 10.1+.

## Yêu cầu

- JDK 17+
- Maven 3.8+
- Apache Tomcat 10.1+

## Chạy dự án

```bash
mvn clean package
```

Sau khi build thành công, sao chép `target/jsp-pure-dictionary.war` vào thư mục `webapps` của Tomcat. Khởi động Tomcat và truy cập:

```text
http://localhost:8080/jsp-pure-dictionary/
```

Từ mẫu có sẵn: `hello`, `book`, `computer`, `student`, `school`, `apple`.
