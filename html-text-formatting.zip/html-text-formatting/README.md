# Thực hành định dạng văn bản với HTML Styles

Mở file `index.html` bằng Chrome, Firefox hoặc Edge để xem kết quả.

Bài thực hành sử dụng:

- Thẻ tiêu đề `h1`;
- Thẻ đoạn văn `p`;
- Thẻ chữ đậm `b`;
- Thẻ chữ nghiêng `i`;
- Thẻ gạch chân `u`;
- Danh sách `ul` và `li`;
- CSS nội tuyến: `color`, `font-size`, `text-align`, `font-family`, `font-weight`.

## Chạy bài

Nhấp đúp vào `index.html`, hoặc mở bằng trình duyệt:

```text
file:///duong-dan-den/html-text-formatting/index.html
```

## Nộp bài

Đưa file `index.html` hoặc toàn bộ thư mục này lên GitHub rồi nộp link repository.
