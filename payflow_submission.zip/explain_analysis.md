# Phân tích EXPLAIN trước và sau tối ưu

Truy vấn cũ dùng `YEAR(created_at)` và `MONTH(created_at)` trong `WHERE`. Vì hàm được áp dụng lên cột, điều kiện trở thành **Non-SARGable**: MySQL khó dùng B-Tree Index để tìm trực tiếp theo khoảng ngày và thường phải quét toàn bảng. Khi đó `EXPLAIN` thường cho `type = ALL`, `key = NULL`, còn `rows` xấp xỉ toàn bộ số dòng của `Transactions`.

Giải pháp tạo composite index `idx_type_date(transaction_type, created_at)`. Truy vấn mới giữ điều kiện bằng trên `transaction_type`, đồng thời thay hàm ngày bằng khoảng `[2026-06-01, 2026-07-01)`. Điều kiện này **SARGable**, cho phép MySQL tìm theo index. Kết quả `EXPLAIN` kỳ vọng có `possible_keys` và `key` là `idx_type_date`, `type` chuyển sang `range` (hoặc kế hoạch tương đương), và `rows` giảm mạnh xuống số bản ghi phù hợp. Giá trị `rows` thực tế phụ thuộc dữ liệu và thống kê optimizer; cần chạy `ANALYZE TABLE Transactions` nếu thống kê cũ.

Index không làm truy vấn tự động nhanh trong mọi trường hợp, nhưng loại bỏ việc tính hàm trên hàng triệu dòng và giới hạn vùng quét theo loại giao dịch cùng khoảng thời gian.
