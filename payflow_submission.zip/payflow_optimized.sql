-- PAYFLOW: TỐI ƯU HÓA TRUY VẤN BÁO CÁO DEPOSIT
-- MySQL 8.x

CREATE DATABASE IF NOT EXISTS payflow_db;
USE payflow_db;

CREATE TABLE IF NOT EXISTS Transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    amount DECIMAL(15,2),
    transaction_type VARCHAR(20),
    created_at DATETIME
);

-- Truy vấn cũ (Non-SARGable) để đối chiếu.
-- YEAR() và MONTH() bọc quanh created_at, làm cản trở việc dùng
-- B-Tree Index trên cột ngày tháng.
EXPLAIN
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND YEAR(created_at) = 2026
  AND MONTH(created_at) = 6;

-- Index kết hợp: lọc theo loại giao dịch trước, sau đó tìm theo khoảng ngày.
CREATE INDEX idx_type_date
    ON Transactions (transaction_type, created_at);

-- Truy vấn mới: điều kiện khoảng thời gian là SARGable.
-- Dùng cận dưới bao gồm và cận trên loại trừ để bao phủ chính xác tháng 06/2026.
EXPLAIN
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND created_at >= '2026-06-01 00:00:00'
  AND created_at <  '2026-07-01 00:00:00';

-- Truy vấn chạy báo cáo thực tế (không hiển thị execution plan):
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND created_at >= '2026-06-01 00:00:00'
  AND created_at <  '2026-07-01 00:00:00';

-- Tùy chọn đo thời gian trên môi trường MySQL hỗ trợ profiling:
-- SET profiling = 1;
-- SELECT ...truy_vấn_báo_cáo...;
-- SHOW PROFILES;
