# AI Prompt Log — PayFlow EXPLAIN và Index

## Prompt 1
**Hỏi:** Vì sao `WHERE YEAR(created_at) = 2026 AND MONTH(created_at) = 6` có thể làm MySQL quét toàn bảng dù đã có index ngày tháng?

**Trả lời tóm tắt:** Đây là điều kiện Non-SARGable vì hàm được áp dụng lên cột. Database phải tính hàm trên nhiều dòng trước khi so sánh, nên không thể tìm trực tiếp bằng thứ tự B-Tree như một khoảng giá trị.

## Prompt 2
**Hỏi:** Vì sao nên viết khoảng `created_at >= '2026-06-01' AND created_at < '2026-07-01'`?

**Trả lời tóm tắt:** Đây là điều kiện SARGable. Cận dưới bao gồm và cận trên loại trừ bao phủ trọn tháng, không phụ thuộc số ngày hay phần thời gian trong ngày, đồng thời cho phép Index Range Scan.

## Prompt 3
**Hỏi:** Thứ tự cột trong index `(transaction_type, created_at)` có quan trọng không?

**Trả lời tóm tắt:** Có. MySQL thường sử dụng phần đầu của composite index trước. `transaction_type` đứng trước vì truy vấn lọc bằng so sánh bằng, sau đó `created_at` dùng để lọc theo range. Khi đổi thứ tự, khả năng tận dụng đồng thời hai điều kiện có thể giảm.

## Prompt 4
**Hỏi:** `type = ALL`, `range` và `ref` trong EXPLAIN nghĩa là gì?

**Trả lời tóm tắt:** `ALL` là quét toàn bảng và thường tốn kém nhất. `range` là quét một khoảng trong index. `ref` là tra cứu các giá trị khớp qua index không duy nhất. Với truy vấn này, `range` là kết quả kỳ vọng vì created_at được lọc theo khoảng.

## Prompt 5
**Hỏi:** Tạo nhiều index có rủi ro gì khi bảng có INSERT/UPDATE/DELETE liên tục?

**Trả lời tóm tắt:** Mỗi thay đổi dữ liệu phải cập nhật thêm các cấu trúc index, làm tăng chi phí ghi, dung lượng lưu trữ và khả năng tranh chấp. Vì vậy chỉ nên tạo index phục vụ truy vấn thực tế.
