# Bài tập sử dụng bộ chọn CSS

Mở `index.html` bằng trình duyệt để xem kết quả.

File `style.css` minh họa các bộ chọn:

- **Element selector**: `body`, `h1` và `li`;
- **Class selector**: `.introduction`, `.hobby-list`;
- **ID selector**: `#page-container`, `#action-button`;
- **Grouping selector**: `h2, h1`;
- **Pseudo-class**: `#action-button:hover` tạo hiệu ứng khi di chuột lên nút.

Trang có màu nền, tiêu đề căn giữa, danh sách với các màu khác nhau và nút **Nhấn vào đây** có hover effect.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
