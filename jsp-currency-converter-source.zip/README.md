# JSP Currency Converter

Ứng dụng Maven Webapp đơn giản chuyển đổi USD sang VNĐ bằng JSP Scriptlet và Expression, tương thích với Apache Tomcat 10.1+.

## Yêu cầu

- JDK 17 hoặc mới hơn
- Maven 3.8+
- Apache Tomcat 10.1+

## Chạy dự án

Từ thư mục gốc dự án, chạy:

```bash
mvn clean package
```

Sau khi build thành công, file `target/jsp-currency-converter.war` sẽ được tạo. Sao chép file này vào thư mục `webapps` của Tomcat, khởi động Tomcat và truy cập:

```text
http://localhost:8080/jsp-currency-converter/
```

## Cấu trúc dự án

```text
jsp-currency-converter/
├── pom.xml
├── README.md
└── src/main/webapp/
    ├── index.jsp
    ├── converter.jsp
    └── WEB-INF/web.xml
```
