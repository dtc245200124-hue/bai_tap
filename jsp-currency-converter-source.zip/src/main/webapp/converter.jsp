<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.text.NumberFormat" %>
<%@ page import="java.util.Locale" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kết quả chuyển đổi</title>
    <style>
        :root { --primary: #1b2a7a; --background: #f8fafc; }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px; font-family: Arial, sans-serif; background: var(--background); }
        .result-container { width: min(100%, 460px); padding: 36px; border-radius: 14px; background: #fff; box-shadow: 0 8px 24px rgba(0, 0, 0, .12); text-align: center; }
        h1 { margin: 0 0 24px; color: var(--primary); font-size: 26px; }
        .detail { margin: 12px 0; color: #475569; font-size: 17px; }
        .amount { margin: 24px 0; padding: 18px; border-radius: 9px; background: #e8f5e9; color: #16803c; font-size: 25px; font-weight: 700; }
        .error { margin: 24px 0; padding: 18px; border-radius: 9px; background: #ffebee; color: #b42318; }
        .back-btn { display: inline-block; margin-top: 4px; padding: 11px 20px; border-radius: 7px; background: var(--primary); color: white; text-decoration: none; font-weight: 700; }
        .back-btn:hover { background: #121c54; }
    </style>
</head>
<body>
<main class="result-container">
    <h1>Kết quả chuyển đổi</h1>
    <%
        String rateInput = request.getParameter("rate");
        String usdInput = request.getParameter("usd");
        boolean valid = false;
        double rate = 0;
        double usd = 0;
        double vnd = 0;
        String formattedVnd = "";

        try {
            if (rateInput != null && usdInput != null) {
                rate = Double.parseDouble(rateInput);
                usd = Double.parseDouble(usdInput);
                if (Double.isFinite(rate) && Double.isFinite(usd) && rate >= 0 && usd >= 0) {
                    vnd = rate * usd;
                    valid = Double.isFinite(vnd);
                    NumberFormat formatter = NumberFormat.getNumberInstance(new Locale("vi", "VN"));
                    formatter.setMaximumFractionDigits(2);
                    formattedVnd = formatter.format(vnd);
                }
            }
        } catch (NumberFormatException ignored) {
            valid = false;
        }

        if (valid) {
    %>
        <p class="detail">Tỉ giá: <strong><%= rate %></strong> VNĐ/USD</p>
        <p class="detail">Số USD: <strong>$<%= usd %></strong></p>
        <div class="amount">Thành tiền: <%= formattedVnd %> VNĐ</div>
    <%
        } else {
    %>
        <div class="error">
            <strong>Dữ liệu không hợp lệ</strong>
            <p>Vui lòng nhập các giá trị số không âm và thử lại.</p>
        </div>
    <%
        }
    %>
    <a class="back-btn" href="index.jsp">Quay lại</a>
</main>
</body>
</html>
