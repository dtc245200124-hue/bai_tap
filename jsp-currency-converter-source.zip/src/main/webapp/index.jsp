<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chuyển đổi USD sang VNĐ</title>
    <style>
        :root { --primary: #1b2a7a; --background: #f8fafc; --text: #1f2937; }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px; font-family: Arial, sans-serif; background: var(--background); color: var(--text); }
        .converter-container { width: min(100%, 420px); padding: 36px; border-radius: 14px; background: #fff; box-shadow: 0 8px 24px rgba(0, 0, 0, .12); }
        h1 { margin: 0 0 8px; color: var(--primary); font-size: 26px; text-align: center; }
        .description { margin: 0 0 28px; color: #64748b; text-align: center; }
        label { display: block; margin: 16px 0 7px; font-weight: 700; }
        input { width: 100%; padding: 12px 14px; border: 1px solid #cbd5e1; border-radius: 7px; font-size: 16px; }
        input:focus { outline: 2px solid #93c5fd; border-color: #2563eb; }
        button { width: 100%; margin-top: 24px; padding: 13px 18px; border: 0; border-radius: 7px; background: var(--primary); color: #fff; font-size: 16px; font-weight: 700; cursor: pointer; }
        button:hover { background: #121c54; }
    </style>
</head>
<body>
<main class="converter-container">
    <h1>USD → VNĐ</h1>
    <p class="description">Nhập tỉ giá và số tiền cần chuyển đổi</p>
    <form action="converter.jsp" method="post">
        <label for="rate">Tỉ giá (VNĐ/USD)</label>
        <input id="rate" type="number" name="rate" value="25000" min="0" step="any" required>

        <label for="usd">Lượng USD cần đổi</label>
        <input id="usd" type="number" name="usd" min="0" step="any" placeholder="Ví dụ: 100" required>

        <button type="submit">Tính toán</button>
    </form>
</main>
</body>
</html>
