package com.codegym;

public class Main {
    public static void main(String[] args) {
        System.out.println("Giải phương trình bậc 2 bằng thư viện quadratic-lib:");
        printEquation(1, -3, 2); // x^2 - 3x + 2 = 0
        printEquation(1, 2, 1);  // x^2 + 2x + 1 = 0
        printEquation(1, 1, 1);  // x^2 + x + 1 = 0
        printEquation(0, 2, -6); // Phương trình suy biến: 2x - 6 = 0
        printEquation(0, 0, 5);  // Vô nghiệm
    }

    private static void printEquation(double a, double b, double c) {
        System.out.printf("%.0fx^2 + %.0fx + %.0f = 0 -> %s%n",
                a, b, c, QuadraticEquationSolver.solve(a, b, c));
    }
}
