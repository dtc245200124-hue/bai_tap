# Bài tập đóng gói thư viện giải phương trình bậc 2

Project gồm hai phần:

- `quadratic-lib`: thư viện Maven chứa lớp `com.codegym.QuadraticEquationSolver`.
- `quadratic-app`: ứng dụng Java Console sử dụng file `lib/quadratic-lib.jar`.

## Chức năng

Thư viện giải phương trình `ax² + bx + c = 0` và xử lý:

- Hai nghiệm phân biệt (`delta > 0`);
- Nghiệm kép (`delta = 0`);
- Vô nghiệm thực (`delta < 0`);
- Phương trình suy biến thành bậc nhất (`a = 0`);
- Vô số nghiệm hoặc vô nghiệm khi `a = 0, b = 0`.

## Build và chạy bằng Maven

```bash
cd quadratic-lib
mvn clean package
cp target/quadratic-lib-1.0.jar ../quadratic-app/lib/quadratic-lib.jar

cd ../quadratic-app
mvn clean compile
mvn exec:java
```

## Build và chạy không cần Maven

```bash
cd quadratic-lib
mkdir -p target/classes
javac -d target/classes src/main/java/com/codegym/QuadraticEquationSolver.java
jar cf target/quadratic-lib-1.0.jar -C target/classes .
cp target/quadratic-lib-1.0.jar ../quadratic-app/lib/quadratic-lib.jar

cd ../quadratic-app
mkdir -p target/classes
javac -cp lib/quadratic-lib.jar -d target/classes src/main/java/com/codegym/Main.java
java -cp "target/classes:lib/quadratic-lib.jar" com.codegym.Main
```

Trên Windows, thay dấu `:` trong classpath bằng dấu `;`.

## Kết quả mẫu

```text
1x^2 + -3x + 2 = 0 -> Hai nghiệm phân biệt: x1 = 2, x2 = 1
1x^2 + 2x + 1 = 0 -> Nghiệm kép: x1 = x2 = -1
1x^2 + 1x + 1 = 0 -> Vô nghiệm thực
0x^2 + 2x + -6 = 0 -> Nghiệm kép của phương trình suy biến: x = 3
0x^2 + 0x + 5 = 0 -> Vô nghiệm
```

## Đưa bài lên GitHub

```bash
git init
git add .
git commit -m "Complete quadratic equation library packaging exercise"
git branch -M main
git remote add origin https://github.com/<username>/<repository>.git
git push -u origin main
```

Giữ lại file `quadratic-app/lib/quadratic-lib.jar` trong repository vì đây là thư viện được nhúng và sử dụng bởi ứng dụng.
