package com.codegym;

import java.util.Locale;

/** Utility methods for solving ax^2 + bx + c = 0. */
public final class QuadraticEquationSolver {
    private static final double EPSILON = 1e-10;

    private QuadraticEquationSolver() {
        // Utility class.
    }

    /**
     * Returns a Vietnamese description of the equation's solution(s).
     * Supports both quadratic equations and the degenerate linear case.
     */
    public static String solve(double a, double b, double c) {
        if (isZero(a)) {
            if (isZero(b)) {
                return isZero(c) ? "Vô số nghiệm" : "Vô nghiệm";
            }
            return "Nghiệm kép của phương trình suy biến: x = " + format(-c / b);
        }

        double delta = b * b - 4 * a * c;
        if (delta < -EPSILON) {
            return "Vô nghiệm thực";
        }
        if (isZero(delta)) {
            return "Nghiệm kép: x1 = x2 = " + format(-b / (2 * a));
        }

        double sqrtDelta = Math.sqrt(delta);
        double x1 = (-b + sqrtDelta) / (2 * a);
        double x2 = (-b - sqrtDelta) / (2 * a);
        return "Hai nghiệm phân biệt: x1 = " + format(x1) + ", x2 = " + format(x2);
    }

    private static boolean isZero(double value) {
        return Math.abs(value) < EPSILON;
    }

    private static String format(double value) {
        if (isZero(value)) value = 0;
        return String.format(Locale.US, "%.6f", value)
                .replaceAll("0+$", "")
                .replaceAll("\\.$", "");
    }
}
