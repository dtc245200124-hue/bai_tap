# Product Management MVC

Ứng dụng Java Web quản lý sản phẩm theo kiến trúc MVC, dùng Servlet, JSP và JSTL. Dữ liệu được lưu trong `LinkedHashMap` tĩnh để mô phỏng cơ sở dữ liệu.

## Chức năng

- Hiển thị danh sách sản phẩm
- Tìm kiếm sản phẩm theo tên
- Thêm sản phẩm
- Cập nhật sản phẩm
- Xoá sản phẩm
- Xem chi tiết sản phẩm

## Yêu cầu

- JDK 17+
- Maven 3.8+
- Apache Tomcat 10.1+

## Chạy dự án

```bash
mvn clean package
```

Sao chép `target/product-management.war` vào thư mục `webapps` của Tomcat, khởi động Tomcat và truy cập:

```text
http://localhost:8080/product-management/products
```

## Cấu trúc MVC

- `model/Product.java`: mô hình sản phẩm.
- `service/ProductService.java`: hợp đồng nghiệp vụ.
- `service/ProductServiceImpl.java`: triển khai lưu trữ bằng `Map`.
- `controller/ProductServlet.java`: điều hướng các action CRUD và search.
- `webapp/product/*.jsp`: các giao diện JSP/JSTL.
