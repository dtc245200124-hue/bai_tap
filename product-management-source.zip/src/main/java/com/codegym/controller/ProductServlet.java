package com.codegym.controller;

import com.codegym.model.Product;
import com.codegym.service.ProductService;
import com.codegym.service.ProductServiceImpl;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/** Routes product CRUD and search requests to the service and JSP views. */
@WebServlet(name = "ProductServlet", urlPatterns = "/products")
public class ProductServlet extends HttpServlet {
    private final ProductService productService = new ProductServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = valueOrDefault(request.getParameter("action"), "list");
        switch (action) {
            case "create" -> forward(request, response, "product/create.jsp");
            case "edit" -> showProductForm(request, response, "product/edit.jsp");
            case "delete" -> showProductForm(request, response, "product/delete.jsp");
            case "view" -> showProductForm(request, response, "product/view.jsp");
            case "search" -> listProducts(request, response);
            default -> listProducts(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = valueOrDefault(request.getParameter("action"), "");
        try {
            switch (action) {
                case "create" -> createProduct(request, response);
                case "edit" -> updateProduct(request, response);
                case "delete" -> deleteProduct(request, response);
                default -> response.sendRedirect(request.getContextPath() + "/products");
            }
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Dữ liệu sản phẩm không hợp lệ.");
            forward(request, response, "product/create.jsp");
        }
    }

    private void listProducts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String keyword = request.getParameter("keyword");
        request.setAttribute("products", productService.searchByName(keyword));
        request.setAttribute("keyword", keyword == null ? "" : keyword);
        forward(request, response, "product/list.jsp");
    }

    private void createProduct(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        productService.save(readProduct(request, 0));
        response.sendRedirect(request.getContextPath() + "/products");
    }

    private void updateProduct(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        if (productService.findById(id) == null) {
            response.sendRedirect(request.getContextPath() + "/error-404.jsp");
            return;
        }
        productService.update(id, readProduct(request, id));
        response.sendRedirect(request.getContextPath() + "/products?action=view&id=" + id);
    }

    private void deleteProduct(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        productService.remove(id);
        response.sendRedirect(request.getContextPath() + "/products");
    }

    private void showProductForm(HttpServletRequest request, HttpServletResponse response, String view)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Product product = productService.findById(id);
        if (product == null) {
            forward(request, response, "error-404.jsp");
            return;
        }
        request.setAttribute("product", product);
        forward(request, response, view);
    }

    private Product readProduct(HttpServletRequest request, int id) {
        return new Product(id, request.getParameter("name"),
                Double.parseDouble(request.getParameter("price")),
                request.getParameter("description"), request.getParameter("manufacturer"));
    }

    private void forward(HttpServletRequest request, HttpServletResponse response, String path)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher(path);
        dispatcher.forward(request, response);
    }

    private String valueOrDefault(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }
}
