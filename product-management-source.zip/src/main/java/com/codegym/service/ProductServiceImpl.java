package com.codegym.service;

import com.codegym.model.Product;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** In-memory product service used instead of a database for this exercise. */
public class ProductServiceImpl implements ProductService {
    private static final Map<Integer, Product> PRODUCTS = new LinkedHashMap<>();
    private static int nextId = 6;

    static {
        PRODUCTS.put(1, new Product(1, "Laptop Lenovo IdeaPad", 15990000, "Laptop học tập và văn phòng", "Lenovo"));
        PRODUCTS.put(2, new Product(2, "Điện thoại Samsung Galaxy", 8990000, "Điện thoại thông minh màn hình AMOLED", "Samsung"));
        PRODUCTS.put(3, new Product(3, "Tai nghe không dây", 1290000, "Tai nghe Bluetooth chống ồn", "Sony"));
        PRODUCTS.put(4, new Product(4, "Bàn phím cơ", 990000, "Bàn phím cơ dành cho game thủ", "Keychron"));
        PRODUCTS.put(5, new Product(5, "Màn hình Dell 24 inch", 4290000, "Màn hình IPS Full HD", "Dell"));
    }

    @Override
    public List<Product> findAll() {
        return new ArrayList<>(PRODUCTS.values());
    }

    @Override
    public List<Product> searchByName(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return findAll();
        }
        String normalized = keyword.trim().toLowerCase(Locale.ROOT);
        List<Product> matches = new ArrayList<>();
        for (Product product : PRODUCTS.values()) {
            if (product.getName().toLowerCase(Locale.ROOT).contains(normalized)) {
                matches.add(product);
            }
        }
        return matches;
    }

    @Override
    public Product findById(int id) {
        return PRODUCTS.get(id);
    }

    @Override
    public void save(Product product) {
        product.setId(nextId++);
        PRODUCTS.put(product.getId(), product);
    }

    @Override
    public void update(int id, Product product) {
        product.setId(id);
        PRODUCTS.put(id, product);
    }

    @Override
    public void remove(int id) {
        PRODUCTS.remove(id);
    }
}
