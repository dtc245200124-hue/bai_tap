<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Thêm sản phẩm</title>
<style>*{box-sizing:border-box}body{margin:0;padding:30px 20px;background:#f1f5f9;font-family:Arial,sans-serif}.card{width:min(600px,100%);margin:auto;padding:32px;background:#fff;border-radius:12px;box-shadow:0 6px 20px #0f172a18}h1{margin-top:0;color:#1d4ed8}label{display:block;margin:15px 0 7px;font-weight:700}input,textarea{width:100%;padding:11px;border:1px solid #cbd5e1;border-radius:7px;font:inherit}textarea{min-height:100px;resize:vertical}.buttons{display:flex;gap:10px;margin-top:22px}.btn{padding:11px 17px;border:0;border-radius:7px;text-decoration:none;font-weight:700;cursor:pointer}.save{background:#16a34a;color:#fff}.back{background:#e2e8f0;color:#334155}.error{padding:12px;background:#fee2e2;color:#b91c1c;border-radius:7px}</style></head>
<body><main class="card"><h1>Thêm sản phẩm</h1><% if (request.getAttribute("errorMessage") != null) { %><div class="error"><%= request.getAttribute("errorMessage") %></div><% } %>
<form action="${pageContext.request.contextPath}/products?action=create" method="post"><label for="name">Tên sản phẩm</label><input id="name" name="name" required>
<label for="price">Giá sản phẩm (VNĐ)</label><input id="price" name="price" type="number" min="0" step="any" required>
<label for="description">Mô tả</label><textarea id="description" name="description" required></textarea>
<label for="manufacturer">Nhà sản xuất</label><input id="manufacturer" name="manufacturer" required>
<div class="buttons"><button class="btn save" type="submit">Lưu sản phẩm</button><a class="btn back" href="${pageContext.request.contextPath}/products">Huỷ</a></div></form></main></body></html>
