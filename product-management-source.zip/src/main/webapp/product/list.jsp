<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý sản phẩm</title>
    <style>
        * { box-sizing: border-box; } body { margin: 0; padding: 34px 20px; background: #f1f5f9; font-family: Arial, sans-serif; color: #0f172a; }
        .page { width: min(1100px, 100%); margin: auto; } h1 { color: #1d4ed8; margin: 0 0 22px; }
        .toolbar { display: flex; gap: 12px; flex-wrap: wrap; align-items: center; margin-bottom: 18px; }
        input { padding: 11px 13px; border: 1px solid #cbd5e1; border-radius: 7px; font-size: 15px; } .search { flex: 1; min-width: 220px; }
        .btn { display: inline-block; padding: 10px 15px; border: 0; border-radius: 7px; text-decoration: none; font-weight: 700; cursor: pointer; }
        .primary { background: #2563eb; color: #fff; } .green { background: #16a34a; color: #fff; } .muted { background: #e2e8f0; color: #334155; }
        table { width: 100%; border-collapse: collapse; overflow: hidden; background: #fff; border-radius: 10px; box-shadow: 0 5px 16px rgba(15,23,42,.08); }
        th, td { padding: 14px 13px; border-bottom: 1px solid #e2e8f0; text-align: left; vertical-align: top; } th { background: #1e3a8a; color: #fff; }
        tr:last-child td { border-bottom: 0; } .actions { white-space: nowrap; } .actions a { margin-right: 8px; color: #2563eb; text-decoration: none; font-weight: 700; }
        .empty { padding: 28px; background: #fff; border-radius: 10px; color: #64748b; text-align: center; } .keyword { color: #475569; margin-bottom: 16px; }
        @media (max-width: 720px) { table { display: block; overflow-x: auto; white-space: nowrap; } }
    </style>
</head>
<body>
<main class="page">
    <h1>Quản lý sản phẩm</h1>
    <div class="toolbar">
        <form action="${pageContext.request.contextPath}/products" method="get" style="display:flex;gap:10px;flex:1;">
            <input type="hidden" name="action" value="search">
            <input class="search" type="search" name="keyword" value="${keyword}" placeholder="Tìm theo tên sản phẩm...">
            <button class="btn primary" type="submit">Tìm kiếm</button>
        </form>
        <a class="btn green" href="${pageContext.request.contextPath}/products?action=create">+ Thêm sản phẩm</a>
    </div>
    <c:if test="${not empty keyword}"><p class="keyword">Kết quả tìm kiếm cho: <strong>${keyword}</strong></p></c:if>
    <c:choose>
        <c:when test="${not empty products}">
            <table>
                <thead><tr><th>ID</th><th>Tên sản phẩm</th><th>Giá</th><th>Mô tả</th><th>Nhà sản xuất</th><th>Thao tác</th></tr></thead>
                <tbody>
                <c:forEach var="product" items="${products}">
                    <tr>
                        <td>${product.id}</td>
                        <td><strong>${product.name}</strong></td>
                        <td><fmt:formatNumber value="${product.price}" type="number" maxFractionDigits="0"/> VNĐ</td>
                        <td>${product.description}</td>
                        <td>${product.manufacturer}</td>
                        <td class="actions">
                            <a href="${pageContext.request.contextPath}/products?action=view&id=${product.id}">Xem</a>
                            <a href="${pageContext.request.contextPath}/products?action=edit&id=${product.id}">Sửa</a>
                            <a href="${pageContext.request.contextPath}/products?action=delete&id=${product.id}">Xoá</a>
                        </td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </c:when>
        <c:otherwise><div class="empty">Không tìm thấy sản phẩm phù hợp.</div></c:otherwise>
    </c:choose>
</main>
</body>
</html>
