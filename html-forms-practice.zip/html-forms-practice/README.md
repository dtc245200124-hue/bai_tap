# Thực hành tạo form đơn giản

Project gồm hai phần.

## Phần 1: Form thông tin cá nhân

File `simple-form.html` có:

- TextBox họ và tên với `name="yourname"`;
- TextBox email với `name="email"`;
- Các checkbox sở thích cùng `name="hobby"`;
- Nút submit **Gửi thông tin**;
- Nút reset **Nhập lại**.

## Phần 2: Form đăng ký học viên

File `student-registration.html` có các trường với tên tiếng Anh phù hợp: `fullName`, `dateOfBirth`, `gender`, `address`, `course`, `studentEmail` và `phoneNumber`.

File `style.css` dùng để căn chỉnh, tạo màu sắc, khoảng cách và font chữ cho form.

Mở `index.html` để chọn từng phần. Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
