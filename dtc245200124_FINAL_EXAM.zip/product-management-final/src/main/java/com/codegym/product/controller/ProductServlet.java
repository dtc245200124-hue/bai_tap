package com.codegym.product.controller;

import com.codegym.product.dao.ProductDAO;
import com.codegym.product.model.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;

@WebServlet("/products/*")
public class ProductServlet extends HttpServlet {
    private final ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getPathInfo();
        try {
            if ("/new".equals(path)) {
                request.getRequestDispatcher("/WEB-INF/views/product-form.jsp").forward(request, response);
            } else if ("/edit".equals(path)) {
                request.setAttribute("product", productDAO.findById(parseId(request)));
                request.getRequestDispatcher("/WEB-INF/views/product-form.jsp").forward(request, response);
            } else {
                request.setAttribute("products", productDAO.findAll());
                request.getRequestDispatcher("/WEB-INF/views/products.jsp").forward(request, response);
            }
        } catch (Exception e) {
            throw new ServletException("Không thể tải dữ liệu sản phẩm", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        try {
            String action = request.getParameter("action");
            if ("create".equals(action)) {
                productDAO.insert(readProduct(request, 0));
            } else if ("update".equals(action)) {
                productDAO.update(readProduct(request, parseId(request)));
            } else if ("delete".equals(action)) {
                productDAO.delete(parseId(request));
            }
            response.sendRedirect(request.getContextPath() + "/products");
        } catch (Exception e) {
            throw new ServletException("Thao tác sản phẩm thất bại", e);
        }
    }

    private Product readProduct(HttpServletRequest request, int id) {
        String name = request.getParameter("name");
        BigDecimal price = new BigDecimal(request.getParameter("price"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        return new Product(id, name, price, quantity);
    }

    private int parseId(HttpServletRequest request) {
        return Integer.parseInt(request.getParameter("id"));
    }
}
