package com.codegym.product.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class ConnectionUtils {
    private static final String URL = env("DB_URL", "jdbc:mysql://localhost:3306/product_management?useSSL=false&serverTimezone=UTC&characterEncoding=UTF-8");
    private static final String USER = env("DB_USER", "root");
    private static final String PASSWORD = env("DB_PASSWORD", "123456");

    private ConnectionUtils() {}

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    private static String env(String key, String fallback) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? fallback : value;
    }
}
