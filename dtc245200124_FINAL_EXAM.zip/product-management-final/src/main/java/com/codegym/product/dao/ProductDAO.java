package com.codegym.product.dao;

import com.codegym.product.model.Product;
import com.codegym.product.util.ConnectionUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
    private static final String SELECT_ALL = "SELECT id, name, price, quantity FROM products ORDER BY id DESC";
    private static final String SELECT_BY_ID = "SELECT id, name, price, quantity FROM products WHERE id = ?";
    private static final String INSERT = "INSERT INTO products(name, price, quantity) VALUES (?, ?, ?)";
    private static final String UPDATE = "UPDATE products SET name = ?, price = ?, quantity = ? WHERE id = ?";
    private static final String DELETE = "DELETE FROM products WHERE id = ?";

    public List<Product> findAll() throws Exception {
        List<Product> products = new ArrayList<>();
        try (Connection connection = ConnectionUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_ALL);
             ResultSet result = statement.executeQuery()) {
            while (result.next()) products.add(map(result));
        }
        return products;
    }

    public Product findById(int id) throws Exception {
        try (Connection connection = ConnectionUtils.getConnection(); PreparedStatement statement = connection.prepareStatement(SELECT_BY_ID)) {
            statement.setInt(1, id);
            try (ResultSet result = statement.executeQuery()) { return result.next() ? map(result) : null; }
        }
    }

    public void insert(Product product) throws Exception {
        try (Connection connection = ConnectionUtils.getConnection(); PreparedStatement statement = connection.prepareStatement(INSERT)) {
            statement.setString(1, product.getName()); statement.setBigDecimal(2, product.getPrice()); statement.setInt(3, product.getQuantity()); statement.executeUpdate();
        }
    }

    public void update(Product product) throws Exception {
        try (Connection connection = ConnectionUtils.getConnection(); PreparedStatement statement = connection.prepareStatement(UPDATE)) {
            statement.setString(1, product.getName()); statement.setBigDecimal(2, product.getPrice()); statement.setInt(3, product.getQuantity()); statement.setInt(4, product.getId()); statement.executeUpdate();
        }
    }

    public void delete(int id) throws Exception {
        try (Connection connection = ConnectionUtils.getConnection(); PreparedStatement statement = connection.prepareStatement(DELETE)) {
            statement.setInt(1, id); statement.executeUpdate();
        }
    }

    private Product map(ResultSet result) throws Exception {
        return new Product(result.getInt("id"), result.getString("name"), result.getBigDecimal("price"), result.getInt("quantity"));
    }
}
