<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!doctype html><html lang="vi"><head><meta charset="UTF-8"><title>Quản lý sản phẩm</title><link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css"></head>
<body><main class="container"><header><div><h1>Quản lý sản phẩm</h1><p>Product Management - Final Module Exam</p></div><a class="button" href="${pageContext.request.contextPath}/products/new">+ Thêm sản phẩm</a></header>
<c:if test="${empty products}"><div class="empty">Chưa có sản phẩm nào trong cơ sở dữ liệu.</div></c:if>
<c:if test="${not empty products}"><div class="table-wrap"><table><thead><tr><th>ID</th><th>Tên sản phẩm</th><th>Giá</th><th>Số lượng</th><th>Thao tác</th></tr></thead><tbody><c:forEach var="product" items="${products}"><tr><td>${product.id}</td><td>${product.name}</td><td><fmt:formatNumber value="${product.price}" type="number" minFractionDigits="0" maxFractionDigits="2"/> đ</td><td>${product.quantity}</td><td class="actions"><a href="${pageContext.request.contextPath}/products/edit?id=${product.id}">Sửa</a><form method="post" action="${pageContext.request.contextPath}/products" onsubmit="return confirm('Bạn có chắc muốn xóa sản phẩm này không?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="${product.id}"><button class="danger" type="submit">Xóa</button></form></td></tr></c:forEach></tbody></table></div></c:if>
</main></body></html>
