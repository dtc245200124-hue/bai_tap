# Final Exam - Product Management

Ứng dụng web quản lý sản phẩm bằng Java Servlet, JSP, JDBC và MySQL.

## Chức năng

- Hiển thị tất cả sản phẩm dưới dạng bảng: ID, tên, giá, số lượng.
- Thêm sản phẩm mới.
- Sửa thông tin sản phẩm.
- Xóa sản phẩm với hộp thoại xác nhận.
- Dữ liệu được lưu trong MySQL.

## Công nghệ

- Java 11+
- Maven
- Servlet 4.0 / JSP / JSTL
- MySQL 8+
- Apache Tomcat 9+

## 1. Tạo database

Chạy file `database/schema.sql`:

```bash
mysql -u root -p < database/schema.sql
```

Mặc định ứng dụng kết nối:

```text
URL: jdbc:mysql://localhost:3306/product_management
User: root
Password: 123456
```

Có thể thay đổi bằng biến môi trường `DB_URL`, `DB_USER`, `DB_PASSWORD`.

## 2. Build project

```bash
mvn clean package
```

Sau khi build thành công, file WAR nằm tại:

```text
target/product-management.war
```

## 3. Chạy bằng Tomcat

Copy `target/product-management.war` vào thư mục `webapps` của Apache Tomcat 9+, khởi động Tomcat và truy cập:

```text
http://localhost:8080/product-management/products
```

## 4. Đưa bài lên GitHub

Đổi tên file ZIP theo mã số sinh viên, ví dụ `20240001_FinalExam.zip`, sau đó:

```bash
git init
git add .
git commit -m "Complete final exam product management application"
git branch -M main
git remote add origin https://github.com/<username>/<repository>.git
git push -u origin main
```

Nộp link repository GitHub theo yêu cầu của lớp.

## Lưu ý bảo mật

Không đưa mật khẩu MySQL thật vào GitHub. Khi triển khai, dùng `DB_URL`, `DB_USER` và `DB_PASSWORD` bằng biến môi trường.
