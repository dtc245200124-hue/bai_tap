package com.codegym.dao;

import com.codegym.model.User;
import java.util.List;

/** Defines JDBC CRUD, country filtering, and name sorting operations. */
public interface IUserDAO {
    void insertUser(User user) throws Exception;
    User selectUser(int id) throws Exception;
    List<User> selectAllUsers() throws Exception;
    List<User> searchByCountry(String country) throws Exception;
    List<User> selectAllUsersSortedByName() throws Exception;
    boolean deleteUser(int id) throws Exception;
    boolean updateUser(User user) throws Exception;
    User getUserById(int id);
    void insertUserStore(User user) throws Exception;
    void addUserTransaction(User user, int[] permissionIds) throws Exception;
    void insertUpdateWithoutTransaction() throws java.sql.SQLException;
    void insertUpdateUseTransaction() throws java.sql.SQLException;
}
