package com.codegym.dao;

import com.codegym.model.User;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** JDBC implementation for CRUD, country search, and name sorting. */
public class UserDAO implements IUserDAO {
    private final String jdbcURL = System.getenv().getOrDefault(
            "USER_DB_URL", "jdbc:mysql://localhost:3306/demo?useSSL=false&serverTimezone=UTC");
    private final String jdbcUsername = System.getenv().getOrDefault("USER_DB_USERNAME", "root");
    private final String jdbcPassword = System.getenv().getOrDefault("USER_DB_PASSWORD", "password");

    private static final String INSERT_SQL = "INSERT INTO users (name, email, country) VALUES (?, ?, ?)";
    private static final String SELECT_BY_ID_SQL = "SELECT id, name, email, country FROM users WHERE id = ?";
    private static final String SELECT_ALL_SQL = "SELECT id, name, email, country FROM users";
    private static final String SEARCH_COUNTRY_SQL = SELECT_ALL_SQL + " WHERE country LIKE ?";
    private static final String SORT_NAME_SQL = SELECT_ALL_SQL + " ORDER BY name ASC";
    private static final String DELETE_SQL = "DELETE FROM users WHERE id = ?";
    private static final String UPDATE_SQL = "UPDATE users SET name = ?, email = ?, country = ? WHERE id = ?";

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
    }

    @Override
    public void insertUser(User user) throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_SQL)) {
            statement.setString(1, user.getName());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getCountry());
            statement.executeUpdate();
        }
    }

    @Override
    public User selectUser(int id) throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_BY_ID_SQL)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return mapUser(resultSet);
                }
            }
        }
        return null;
    }

    @Override
    public User getUserById(int id) {
        String query = "{CALL get_user_by_id(?)}";
        try (Connection connection = getConnection();
             CallableStatement statement = connection.prepareCall(query)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new User(id, resultSet.getString("name"),
                            resultSet.getString("email"), resultSet.getString("country"));
                }
            }
        } catch (SQLException exception) {
            throw new IllegalStateException("Không thể gọi stored procedure get_user_by_id.", exception);
        }
        return null;
    }

    @Override
    public void insertUserStore(User user) throws SQLException {
        String query = "{CALL insert_user(?, ?, ?)}";
        try (Connection connection = getConnection();
             CallableStatement statement = connection.prepareCall(query)) {
            statement.setString(1, user.getName());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getCountry());
            statement.executeUpdate();
        }
    }

    @Override
    public void addUserTransaction(User user, int[] permissionIds) throws SQLException {
        String insertUserSql = "INSERT INTO users (name, email, country) VALUES (?, ?, ?)";
        String insertPermissionSql = "INSERT INTO user_permission (user_id, permission_id) VALUES (?, ?)";

        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);
            try {
                int userId;
                try (PreparedStatement userStatement = connection.prepareStatement(
                        insertUserSql, Statement.RETURN_GENERATED_KEYS)) {
                    userStatement.setString(1, user.getName());
                    userStatement.setString(2, user.getEmail());
                    userStatement.setString(3, user.getCountry());
                    userStatement.executeUpdate();

                    try (ResultSet keys = userStatement.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new SQLException("Không lấy được ID của User mới.");
                        }
                        userId = keys.getInt(1);
                    }
                }

                if (permissionIds != null && permissionIds.length > 0) {
                    try (PreparedStatement permissionStatement = connection.prepareStatement(insertPermissionSql)) {
                        for (int permissionId : permissionIds) {
                            permissionStatement.setInt(1, userId);
                            permissionStatement.setInt(2, permissionId);
                            permissionStatement.executeUpdate();
                        }
                    }
                }
                connection.commit();
            } catch (SQLException exception) {
                try {
                    connection.rollback();
                } catch (SQLException rollbackException) {
                    exception.addSuppressed(rollbackException);
                }
                throw exception;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    @Override
    public void insertUpdateWithoutTransaction() {
        String insertSql = "INSERT INTO Employee (name, salary, created_Date) VALUES (?, ?, ?)";
        String updateSql = "UPDATE Employee SET salary = ? WHERE name = ?";
        String createSql = "CREATE TABLE Employee (id INT AUTO_INCREMENT, name VARCHAR(100) NOT NULL, salary DECIMAL(15, 2) NOT NULL, created_Date TIMESTAMP, PRIMARY KEY (id))";

        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             PreparedStatement insertStatement = connection.prepareStatement(insertSql);
             PreparedStatement updateStatement = connection.prepareStatement(updateSql)) {
            statement.execute("DROP TABLE IF EXISTS Employee");
            statement.execute(createSql);

            insertStatement.setString(1, "Quynh");
            insertStatement.setBigDecimal(2, new BigDecimal("10"));
            insertStatement.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
            insertStatement.executeUpdate();

            insertStatement.setString(1, "Ngan");
            insertStatement.setBigDecimal(2, new BigDecimal("20"));
            insertStatement.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
            insertStatement.executeUpdate();

            // Cố tình gán tham số 2 trước; tham số 1 chưa được gán nên lệnh update lỗi.
            updateStatement.setBigDecimal(2, new BigDecimal("999.99"));
            updateStatement.setString(2, "Quynh");
            updateStatement.executeUpdate();
        } catch (Exception exception) {
            System.out.println("Đã bắt được lỗi trong quá trình thực thi SQL:");
            exception.printStackTrace();
        }
    }

    @Override
    public void insertUpdateUseTransaction() {
        String insertSql = "INSERT INTO Employee (name, salary, created_Date) VALUES (?, ?, ?)";
        String updateSql = "UPDATE Employee SET salary = ? WHERE name = ?";
        String createSql = "CREATE TABLE Employee (id INT AUTO_INCREMENT, name VARCHAR(100) NOT NULL, salary DECIMAL(15, 2) NOT NULL, created_Date TIMESTAMP, PRIMARY KEY (id))";

        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             PreparedStatement insertStatement = connection.prepareStatement(insertSql);
             PreparedStatement updateStatement = connection.prepareStatement(updateSql)) {
            statement.execute("DROP TABLE IF EXISTS Employee");
            statement.execute(createSql);

            // Bắt đầu transaction: các INSERT chưa được ghi vĩnh viễn.
            connection.setAutoCommit(false);

            insertStatement.setString(1, "Quynh");
            insertStatement.setBigDecimal(2, new BigDecimal("10"));
            insertStatement.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
            insertStatement.executeUpdate();

            insertStatement.setString(1, "Ngan");
            insertStatement.setBigDecimal(2, new BigDecimal("20"));
            insertStatement.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
            insertStatement.executeUpdate();

            // CỐ TÌNH GÂY LỖI để kiểm tra rollback. Sửa 2 thành 1 để commit thành công.
            updateStatement.setBigDecimal(2, new BigDecimal("999.99"));
            updateStatement.setString(2, "Quynh");
            updateStatement.executeUpdate();

            connection.commit();
            connection.setAutoCommit(true);
        } catch (Exception exception) {
            System.out.println("Lỗi xảy ra, các thay đổi chưa commit sẽ bị huỷ khi đóng kết nối:");
            exception.printStackTrace();
        }
    }

    @Override
    public List<User> selectAllUsers() throws SQLException {
        return queryUsers(SELECT_ALL_SQL);
    }

    @Override
    public List<User> searchByCountry(String country) throws SQLException {
        if (country == null || country.isBlank()) {
            return selectAllUsers();
        }
        List<User> users = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(SEARCH_COUNTRY_SQL)) {
            statement.setString(1, "%" + country.trim() + "%");
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    users.add(mapUser(resultSet));
                }
            }
        }
        return users;
    }

    @Override
    public List<User> selectAllUsersSortedByName() throws SQLException {
        return queryUsers(SORT_NAME_SQL);
    }

    @Override
    public boolean deleteUser(int id) throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_SQL)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }

    @Override
    public boolean updateUser(User user) throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_SQL)) {
            statement.setString(1, user.getName());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getCountry());
            statement.setInt(4, user.getId());
            return statement.executeUpdate() > 0;
        }
    }

    private List<User> queryUsers(String sql) throws SQLException {
        List<User> users = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                users.add(mapUser(resultSet));
            }
        }
        return users;
    }

    private User mapUser(ResultSet resultSet) throws SQLException {
        return new User(resultSet.getInt("id"), resultSet.getString("name"),
                resultSet.getString("email"), resultSet.getString("country"));
    }
}
