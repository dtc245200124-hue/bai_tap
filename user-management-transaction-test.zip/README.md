# User Management JDBC, Stored Procedures và Transaction

Ứng dụng Java Web quản lý User theo MVC, sử dụng Servlet, JSP, JSTL, JDBC và MySQL. Ứng dụng hỗ trợ CRUD, tìm kiếm theo `country`, sắp xếp theo `name`, Stored Procedure và các bài thực hành transaction.

## Bài kiểm thử không dùng transaction

Route `/users?action=test-without-tran` chèn hai dòng vào bảng `Employee`, sau đó cố tình làm lỗi câu lệnh UPDATE khi auto-commit vẫn bật. Kết quả minh hoạ là hai dòng INSERT vẫn còn trong database dù UPDATE thất bại.

## Bài kiểm thử có transaction

Route `/users?action=test-use-tran` tắt auto-commit bằng `connection.setAutoCommit(false)`, chèn hai dòng và thực hiện UPDATE trong cùng một transaction. Phiên bản hiện tại cố tình gán sai tham số UPDATE:

```java
updateStatement.setBigDecimal(2, new BigDecimal("999.99"));
```

Khi chạy lần đầu, lỗi xảy ra trước `commit()` và các thay đổi chưa commit sẽ bị huỷ khi connection đóng. Để chạy trường hợp thành công, sửa chỉ số tham số từ `2` thành `1`, sau đó build và deploy lại:

```java
updateStatement.setBigDecimal(1, new BigDecimal("999.99"));
```

Khi đó hai User được chèn và lương của `Quynh` được cập nhật trong cùng một lần `commit()`.

## Khởi tạo MySQL

Chạy toàn bộ file `schema.sql` trong MySQL Workbench, DBeaver hoặc terminal. Script tạo database `demo`, các bảng `users`, `permission`, `user_permission`, `Employee`, dữ liệu mẫu và Stored Procedure.

## Cấu hình kết nối

Thiết lập các biến môi trường sau trước khi chạy Tomcat:

```text
USER_DB_URL=jdbc:mysql://localhost:3306/demo?useSSL=false&serverTimezone=UTC
USER_DB_USERNAME=root
USER_DB_PASSWORD=your-password
```

Không đưa mật khẩu thật lên GitHub.

## Chạy dự án

```bash
mvn clean package
```

Sao chép `target/user-management.war` vào thư mục `webapps` của Tomcat 10.1+, khởi động Tomcat rồi truy cập:

```text
http://localhost:8080/user-management/users
```
