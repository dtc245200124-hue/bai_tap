# Layout Refactoring — CreativeChronicle

Bản cũ dùng `float` cho Author Info nên phần tử cha phải clearfix; khi nội dung dài, việc căn giữa dọc và giữ nút chia sẻ cùng hàng trở nên khó kiểm soát. Bản mới dùng **Flexbox** với `align-items-center`, `justify-content-between`, `flex-wrap` và `gap`. Cấu trúc này tự điều chỉnh theo độ dài tên tác giả.

Mosaic cũ dùng `position: absolute` và chiều cao cố định. Phần tử tuyệt đối bị loại khỏi luồng tài liệu, nên chiều cao thực tế của cha không phản ánh nội dung và văn bản bên dưới dễ bị đè. Bản mới dùng **CSS Grid** với hai cột `2fr 1fr`; ảnh chính `grid-row: span 2`, còn ảnh phụ tự lấp hai ô. Mobile chuyển thành một cột.

Recommended Articles dùng **Bootstrap Grid** với `col-12 col-md-6 col-lg-3`, nên tự xếp 1, 2 hoặc 4 cột theo breakpoint.

## References

[1]: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout "MDN CSS grid layout"
