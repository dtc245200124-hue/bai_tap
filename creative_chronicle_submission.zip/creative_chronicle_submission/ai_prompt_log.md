# AI Prompt Log — CreativeChronicle

## Prompt 1 — Float và Flexbox

**Câu hỏi:** Vì sao Author Info nên dùng Flexbox thay vì float?

**Kết luận áp dụng:** Flexbox xử lý trực tiếp một hàng nội dung và hỗ trợ `align-items: center`, `justify-content: space-between`, `flex-wrap` và `gap`. Float cần cơ chế clear, không có mô hình căn chỉnh dọc rõ ràng và dễ bị ảnh hưởng khi tên tác giả dài.

## Prompt 2 — Mosaic với CSS Grid

**Câu hỏi:** Làm thế nào để tạo một ảnh lớn chiếm hai hàng và hai ảnh nhỏ nằm bên phải?

**Kết luận áp dụng:** Dùng `display: grid`, `grid-template-columns: 2fr 1fr`, hai hàng tự động và `grid-row: span 2` cho ảnh chính. Grid giữ phần tử trong luồng layout và tự tạo hàng mới khi bổ sung ảnh.

## Prompt 3 — Responsive Mosaic

**Câu hỏi:** Mosaic nên thay đổi thế nào ở màn hình 375px?

**Kết luận áp dụng:** Media query đổi `grid-template-columns` thành `1fr`, đặt lại `grid-row` của ảnh chính và để ba ảnh xếp dọc. `object-fit: cover` giữ ảnh không méo.

## Prompt 4 — Bootstrap Breakpoints

**Câu hỏi:** Nên dùng class nào để danh sách có một cột trên mobile, hai cột trên tablet và bốn cột trên desktop?

**Kết luận áp dụng:** Dùng `col-12 col-md-6 col-lg-3`. Bootstrap cung cấp các breakpoint nhất quán, vì vậy không cần tự viết phần trăm width hoặc float.

## Prompt 5 — Kiểm tra mã nguồn

**Câu hỏi:** Những dấu hiệu nào cho thấy layout cũ đã được loại bỏ?

**Kết luận áp dụng:** CSS mới không chứa `float`, `overflow: hidden` cho clearfix hoặc `position: absolute` cho layout. Author dùng Flexbox, gallery dùng Grid và recommendation dùng `row` cùng các lớp `col-*` của Bootstrap.

## References

[1]: https://getbootstrap.com/docs/5.3/layout/grid/ "Bootstrap 5.3 Grid system"
[2]: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_flexible_box_layout "MDN CSS flexible box layout"
