# Bài tập MySQL JDBC Transaction - Quản lý User

Ứng dụng web Java Servlet/JSP quản lý User, sử dụng MySQL JDBC. Phần trọng tâm là phương thức `addUserTransaction()` trong `UserDAO`.

## 1. Công nghệ

- Java 11+
- Maven
- Servlet/JSP
- MySQL 8+
- Apache Tomcat 9+

## 2. Cài đặt database

Mở MySQL Workbench hoặc terminal và chạy:

```sql
SOURCE database/schema.sql;
```

Mặc định ứng dụng kết nối:

- URL: `jdbc:mysql://localhost:3306/user_management?useSSL=false&serverTimezone=UTC`
- User: `root`
- Password: `123456`

Có thể thay đổi bằng biến môi trường `DB_URL`, `DB_USER`, `DB_PASSWORD`.

## 3. Build và chạy

```bash
mvn clean package
```

Copy file `target/user-management.war` vào thư mục `webapps` của Tomcat 9, khởi động Tomcat, sau đó mở:

```text
http://localhost:8080/user-management/users
```

## 4. Kiểm tra transaction

Trong `src/main/java/com/example/userapp/dao/UserDAO.java`, bỏ comment dòng:

```java
connection.prepareStatement("INSERT INTO table_does_not_exist(x) VALUES (1)").executeUpdate();
```

Sau đó build và chạy lại. Kết quả mong đợi:

1. Câu lệnh thêm user thứ nhất được thực thi.
2. Câu lệnh thứ hai gây lỗi SQL.
3. `catch` gọi `connection.rollback()`.
4. User mới **không xuất hiện** trong database.

Khi comment dòng gây lỗi lại, `connection.commit()` được gọi và user mới được lưu.

## 5. Luồng transaction

```text
setAutoCommit(false)
        |
        v
   INSERT user
        |
   SQL error? ---- Có ----> rollback()
        |
       Không
        v
    commit()
```

## 6. Đưa lên GitHub

```bash
git init
git add .
git commit -m "Complete MySQL JDBC transaction exercise"
git branch -M main
git remote add origin https://github.com/<username>/<repository>.git
git push -u origin main
```

Không commit mật khẩu thật lên GitHub. Với bài nộp cá nhân, nên đổi mật khẩu mặc định trong máy local hoặc dùng biến môi trường.
