<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý User</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<main class="container">
    <div class="header-row">
        <div><h1>Quản lý User</h1><p class="subtitle">JDBC Transaction: commit / rollback</p></div>
        <a class="button" href="${pageContext.request.contextPath}/users/new">+ Thêm user</a>
    </div>
    <c:if test="${empty users}"><div class="empty">Chưa có dữ liệu user.</div></c:if>
    <c:if test="${not empty users}">
    <table>
        <thead><tr><th>ID</th><th>Họ tên</th><th>Email</th><th>Quốc gia</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="user" items="${users}">
            <tr>
                <td>${user.id}</td><td>${user.name}</td><td>${user.email}</td><td>${user.country}</td>
                <td class="actions">
                    <a href="${pageContext.request.contextPath}/users/edit?id=${user.id}">Sửa</a>
                    <form method="post" action="${pageContext.request.contextPath}/users" onsubmit="return confirm('Xóa user này?')">
                        <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="${user.id}">
                        <button class="link-button" type="submit">Xóa</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
    </c:if>
</main>
</body>
</html>
