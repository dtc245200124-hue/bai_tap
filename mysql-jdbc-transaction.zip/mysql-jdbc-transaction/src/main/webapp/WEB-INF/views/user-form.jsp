<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>${empty user ? 'Thêm user' : 'Sửa user'}</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<main class="container narrow">
    <h1>${empty user ? 'Thêm user' : 'Sửa user'}</h1>
    <p class="subtitle">${empty user ? 'Dữ liệu được lưu trong một transaction.' : 'Cập nhật thông tin user.'}</p>
    <form method="post" action="${pageContext.request.contextPath}/users" class="form-card">
        <input type="hidden" name="action" value="${empty user ? 'create' : 'update'}">
        <input type="hidden" name="id" value="${user.id}">
        <label>Họ tên <input required maxlength="100" name="name" value="${user.name}"></label>
        <label>Email <input required type="email" maxlength="150" name="email" value="${user.email}"></label>
        <label>Quốc gia <input required maxlength="80" name="country" value="${user.country}"></label>
        <div class="form-actions"><button class="button" type="submit">Lưu</button><a href="${pageContext.request.contextPath}/users">Hủy</a></div>
    </form>
</main>
</body>
</html>
