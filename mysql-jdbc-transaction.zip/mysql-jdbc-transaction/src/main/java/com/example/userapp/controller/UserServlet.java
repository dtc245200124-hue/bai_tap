package com.example.userapp.controller;

import com.example.userapp.dao.UserDAO;
import com.example.userapp.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/users/*")
public class UserServlet extends HttpServlet {
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getPathInfo();
        try {
            if ("/new".equals(path)) {
                request.getRequestDispatcher("/WEB-INF/views/user-form.jsp").forward(request, response);
            } else if ("/edit".equals(path)) {
                int id = Integer.parseInt(request.getParameter("id"));
                request.setAttribute("user", userDAO.findById(id));
                request.getRequestDispatcher("/WEB-INF/views/user-form.jsp").forward(request, response);
            } else {
                request.setAttribute("users", userDAO.findAll());
                request.getRequestDispatcher("/WEB-INF/views/users.jsp").forward(request, response);
            }
        } catch (SQLException | NumberFormatException e) {
            throw new ServletException("Không thể đọc dữ liệu người dùng", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        try {
            if ("create".equals(action)) {
                User user = new User(request.getParameter("name"), request.getParameter("email"), request.getParameter("country"));
                userDAO.addUserTransaction(user);
            } else if ("update".equals(action)) {
                User user = new User(Integer.parseInt(request.getParameter("id")), request.getParameter("name"), request.getParameter("email"), request.getParameter("country"));
                userDAO.update(user);
            } else if ("delete".equals(action)) {
                userDAO.delete(Integer.parseInt(request.getParameter("id")));
            }
            response.sendRedirect(request.getContextPath() + "/users");
        } catch (SQLException | NumberFormatException e) {
            throw new ServletException("Thao tác với người dùng thất bại", e);
        }
    }
}
