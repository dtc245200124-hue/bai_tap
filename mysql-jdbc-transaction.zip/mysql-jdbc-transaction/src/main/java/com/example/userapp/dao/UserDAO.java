package com.example.userapp.dao;

import com.example.userapp.model.User;
import com.example.userapp.util.ConnectionUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    private static final String INSERT_SQL = "INSERT INTO users(name, email, country) VALUES (?, ?, ?)";
    private static final String SELECT_ALL_SQL = "SELECT id, name, email, country FROM users ORDER BY id DESC";
    private static final String SELECT_BY_ID_SQL = "SELECT id, name, email, country FROM users WHERE id = ?";
    private static final String UPDATE_SQL = "UPDATE users SET name = ?, email = ?, country = ? WHERE id = ?";
    private static final String DELETE_SQL = "DELETE FROM users WHERE id = ?";

    public List<User> findAll() throws SQLException {
        List<User> users = new ArrayList<>();
        try (Connection connection = ConnectionUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_ALL_SQL);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) users.add(map(resultSet));
        }
        return users;
    }

    public User findById(int id) throws SQLException {
        try (Connection connection = ConnectionUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_BY_ID_SQL)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? map(resultSet) : null;
            }
        }
    }

    public void update(User user) throws SQLException {
        try (Connection connection = ConnectionUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_SQL)) {
            statement.setString(1, user.getName());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getCountry());
            statement.setInt(4, user.getId());
            statement.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        try (Connection connection = ConnectionUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_SQL)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        }
    }

    /**
     * Adds a user as one transaction. Any SQL error causes every statement
     * in this method to be rolled back, so partial data is never committed.
     */
    public boolean addUserTransaction(User user) throws SQLException {
        try (Connection connection = ConnectionUtils.getConnection()) {
            connection.setAutoCommit(false);
            try {
                try (PreparedStatement insert = connection.prepareStatement(INSERT_SQL)) {
                    insert.setString(1, user.getName());
                    insert.setString(2, user.getEmail());
                    insert.setString(3, user.getCountry());
                    insert.executeUpdate();
                }

                // Uncomment the next line to intentionally test rollback:
                // connection.prepareStatement("INSERT INTO table_does_not_exist(x) VALUES (1)").executeUpdate();

                connection.commit();
                return true;
            } catch (SQLException exception) {
                connection.rollback();
                throw exception;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    private User map(ResultSet resultSet) throws SQLException {
        return new User(resultSet.getInt("id"), resultSet.getString("name"),
                resultSet.getString("email"), resultSet.getString("country"));
    }
}
