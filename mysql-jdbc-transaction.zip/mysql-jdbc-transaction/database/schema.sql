CREATE DATABASE IF NOT EXISTS user_management
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE user_management;

CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    country VARCHAR(80) NOT NULL
);

INSERT INTO users (name, email, country) VALUES
('Nguyen Van An', 'an@example.com', 'Viet Nam'),
('Tran Thi Binh', 'binh@example.com', 'Viet Nam')
ON DUPLICATE KEY UPDATE name = VALUES(name), country = VALUES(country);
