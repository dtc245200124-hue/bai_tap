package com.codegym.model;

/**
 * Model skeleton representing a customer.
 *
 * TODO: Add fields, constructors, getters, and setters for id, name, email,
 * and address as part of the exercise.
 */
public class Customer {
    // TODO: Declare id, name, email, and address fields.
}
