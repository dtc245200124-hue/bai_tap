package com.codegym.service;

import com.codegym.model.Customer;
import java.util.List;

/**
 * Service contract for customer management operations.
 *
 * TODO: Complete the method signatures and behavior during the exercise.
 */
public interface CustomerService {
    // TODO: Declare findAll, save, findById, update, and remove signatures.
}
