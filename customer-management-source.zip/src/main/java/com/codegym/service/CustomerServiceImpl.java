package com.codegym.service;

/**
 * Skeleton implementation of the customer service.
 *
 * TODO: Add the static Map data store and implement CustomerService methods.
 */
public class CustomerServiceImpl {
    // TODO: Implement the service layer with an in-memory Map.
}
