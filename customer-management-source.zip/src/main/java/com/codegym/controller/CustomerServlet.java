package com.codegym.controller;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;

/**
 * Controller skeleton for customer management requests.
 *
 * TODO: Implement GET/POST routing for list, create, edit, delete, and view
 * actions, then forward requests to the corresponding JSP views.
 */
@WebServlet(name = "CustomerServlet", urlPatterns = "/customers")
public class CustomerServlet extends HttpServlet {
    // TODO: Add the service dependency and request-handling methods.
}
