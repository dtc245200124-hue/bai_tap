<%--
    Error 404 view skeleton.
    TODO: Add the not-found message and navigation link.
--%>
