<%--
    Customer creation view skeleton.
    TODO: Add the customer creation form and JSTL messages.
--%>
