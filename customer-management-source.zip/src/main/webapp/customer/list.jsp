<%--
    Customer list view skeleton.
    TODO: Add JSTL declarations and the customer table.
--%>
