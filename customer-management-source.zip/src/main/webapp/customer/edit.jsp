<%--
    Customer edit view skeleton.
    TODO: Add the customer edit form and request-bound fields.
--%>
