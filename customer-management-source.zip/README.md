# Customer Management MVC

Đây là bộ khung Maven Webapp cho bài tập quản lý khách hàng theo kiến trúc MVC, tương thích Apache Tomcat 10.1+.

Theo đúng yêu cầu của đề bài, dự án hiện chỉ gồm:

- Cấu hình hoàn chỉnh trong `pom.xml` và `WEB-INF/web.xml`.
- Các class Java dạng skeleton có Javadoc và TODO.
- Các file JSP dạng skeleton có comment TODO.
- Chưa có logic nghiệp vụ, xử lý GET/POST hoặc HTML/JSTL hoàn chỉnh.

## Cấu trúc

```text
customer-management/
├── pom.xml
├── README.md
└── src/main/
    ├── java/com/codegym/
    │   ├── model/Customer.java
    │   ├── service/CustomerService.java
    │   ├── service/CustomerServiceImpl.java
    │   └── controller/CustomerServlet.java
    └── webapp/
        ├── error-404.jsp
        ├── WEB-INF/web.xml
        └── customer/
            ├── list.jsp
            ├── create.jsp
            ├── edit.jsp
            ├── delete.jsp
            └── view.jsp
```

## Thư viện

Dự án đã khai báo Jakarta Servlet, Jakarta JSP và JSTL 3.x trong Maven để sẵn sàng cho các bước triển khai tiếp theo.
