# Thực hành đóng gói thư viện Java

Project gồm hai phần:

- `math-lib`: thư viện Maven chứa lớp `com.codegym.Calculator`.
- `calculator-app`: ứng dụng Java Console sử dụng file `lib/math-lib.jar`.

## Chạy nhanh

File `calculator-app/lib/math-lib.jar` đã được đóng gói sẵn trong project.

Nếu máy đã cài Maven:

```bash
cd math-lib
mvn clean package
cp target/math-lib-1.0.jar ../calculator-app/lib/math-lib.jar

cd ../calculator-app
mvn clean compile
mvn exec:java
```

Nếu không dùng Maven, chạy trực tiếp:

```bash
cd math-lib
javac -d target/classes src/main/java/com/codegym/Calculator.java
jar cf target/math-lib-1.0.jar -C target/classes .
cp target/math-lib-1.0.jar ../calculator-app/lib/math-lib.jar

cd ../calculator-app
mkdir -p target/classes
javac -cp lib/math-lib.jar -d target/classes src/main/java/com/codegym/Main.java
java -cp "target/classes:lib/math-lib.jar" com.codegym.Main
```

Trên Windows, thay dấu `:` trong classpath bằng dấu `;`.

## Kết quả mong đợi

```text
Kết quả gọi từ thư viện đóng gói (.jar):
Tổng 2 số (5, 9): 14
Hiệu 2 số (5, 9): -4
Tích 2 số (5, 9): 45
Thương 2 số (10, 5): 2
```

## Kiểm tra exception

Trong `calculator-app/src/main/java/com/codegym/Main.java`, bỏ comment dòng gọi:

```java
Calculator.divide(10, 0)
```

Chương trình sẽ bắt `NoSuchAlgorithmException` do thư viện cố ý ném exception khi mẫu số bằng 0.

## Đưa lên GitHub

```bash
git init
git add .
git commit -m "Complete Java library packaging exercise"
git branch -M main
git remote add origin https://github.com/<username>/<repository>.git
git push -u origin main
```

Nên commit cả thư mục `calculator-app/lib/math-lib.jar` vì đây là nội dung bài yêu cầu nhúng thư viện cục bộ.
