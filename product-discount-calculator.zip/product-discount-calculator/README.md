# Product Discount Calculator

A simple Java Web application using JSP and Jakarta Servlet 6.0, compatible with Apache Tomcat 10.1+.

The home page accepts a product description, list price, and discount percentage. The form submits by POST to `/display-discount`, where `DiscountServlet` calculates:

- Discount Amount = List Price × Discount Percent × 0.01
- Discount Price = List Price − Discount Amount

Prices are rounded to two decimal places using half-up rounding. The discount must be between 0% and 100%, and the list price must be non-negative.

## Build

Requires Java 17+ and Maven. Run from the project root:

```bash
mvn clean package
```

After `BUILD SUCCESS`, the WAR is available at `target/product-discount-calculator.war`.

## Run on Tomcat

Copy the WAR into the `webapps` directory of Tomcat 10.1+ and start the server. Open `http://localhost:8080/product-discount-calculator/` in a browser.
