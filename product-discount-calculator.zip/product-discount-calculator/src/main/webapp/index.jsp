<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Product Discount Calculator</title>
    <style>
        * { box-sizing: border-box; }
        body { min-height: 100vh; display: grid; place-items: center; margin: 0; padding: 24px; font-family: Arial, sans-serif; background: #f1f5f9; color: #172554; }
        .calculator-card { width: min(100%, 460px); padding: 34px; background: white; border-radius: 12px; box-shadow: 0 12px 32px rgba(15, 23, 42, .12); }
        h1 { margin: 0 0 8px; text-align: center; font-size: 1.65rem; }
        .intro { margin: 0 0 24px; text-align: center; color: #64748b; }
        label { display: block; margin: 16px 0 7px; font-weight: 600; }
        input, textarea { width: 100%; padding: 11px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font: inherit; }
        textarea { min-height: 90px; resize: vertical; }
        input:focus, textarea:focus { outline: 2px solid #93c5fd; border-color: #2563eb; }
        button { width: 100%; margin-top: 22px; padding: 12px; border: 0; border-radius: 6px; background: #1b2a7a; color: white; font: inherit; font-weight: 700; cursor: pointer; }
        button:hover { background: #263aa0; }
    </style>
</head>
<body>
    <main class="calculator-card">
        <h1>Product Discount Calculator</h1>
        <p class="intro">Enter the product information to calculate its discount.</p>
        <form action="${pageContext.request.contextPath}/display-discount" method="POST">
            <label for="productDescription">Product Description</label>
            <textarea id="productDescription" name="productDescription" placeholder="Describe the product" required></textarea>
            <label for="listPrice">List Price</label>
            <input id="listPrice" type="number" name="listPrice" min="0" step="0.01" placeholder="e.g. 99.99" required>
            <label for="discountPercent">Discount Percent (%)</label>
            <input id="discountPercent" type="number" name="discountPercent" min="0" max="100" step="0.01" placeholder="e.g. 15" required>
            <button type="submit">Calculate Discount</button>
        </form>
    </main>
</body>
</html>
