package com.codegym;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "DiscountServlet", urlPatterns = "/display-discount")
public class DiscountServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String description = request.getParameter("productDescription");
        String listPriceValue = request.getParameter("listPrice");
        String discountPercentValue = request.getParameter("discountPercent");

        BigDecimal listPrice;
        BigDecimal discountPercent;
        if (description == null || description.isBlank()
                || listPriceValue == null || discountPercentValue == null) {
            showError(response, request, "Please complete all fields.");
            return;
        }

        try {
            listPrice = new BigDecimal(listPriceValue.trim());
            discountPercent = new BigDecimal(discountPercentValue.trim());
        } catch (NumberFormatException ex) {
            showError(response, request, "Please enter valid numeric values for price and discount.");
            return;
        }

        if (listPrice.signum() < 0
                || discountPercent.signum() < 0
                || discountPercent.compareTo(BigDecimal.valueOf(100)) > 0) {
            showError(response, request, "List price must be non-negative and discount must be between 0 and 100%.");
            return;
        }

        BigDecimal discountAmount = listPrice
                .multiply(discountPercent)
                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        BigDecimal discountPrice = listPrice.subtract(discountAmount).setScale(2, RoundingMode.HALF_UP);
        showResult(response, request, description.trim(), listPrice, discountPercent,
                discountAmount, discountPrice);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/");
    }

    private void showResult(HttpServletResponse response, HttpServletRequest request,
                            String description, BigDecimal listPrice, BigDecimal discountPercent,
                            BigDecimal discountAmount, BigDecimal discountPrice) throws IOException {
        NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);
        numberFormat.setMinimumFractionDigits(2);
        numberFormat.setMaximumFractionDigits(2);
        try (PrintWriter out = response.getWriter()) {
            pageStart(out, "Discount Calculation Result");
            out.println("  <h1>Discount Calculation Result</h1>");
            out.println("  <dl>");
            out.println("    <dt>Product Description</dt><dd>" + escapeHtml(description) + "</dd>");
            out.println("    <dt>List Price</dt><dd>" + numberFormat.format(listPrice) + "</dd>");
            out.println("    <dt>Discount Percent</dt><dd>" + numberFormat.format(discountPercent) + "%</dd>");
            out.println("    <dt>Discount Amount</dt><dd class=\"highlight\">" + numberFormat.format(discountAmount) + "</dd>");
            out.println("    <dt>Discount Price</dt><dd class=\"highlight\">" + numberFormat.format(discountPrice) + "</dd>");
            out.println("  </dl>");
            out.println("  <a href=\"" + request.getContextPath() + "/\">Calculate another product</a>");
            pageEnd(out);
        }
    }

    private void showError(HttpServletResponse response, HttpServletRequest request, String message)
            throws IOException {
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        try (PrintWriter out = response.getWriter()) {
            pageStart(out, "Invalid Input");
            out.println("  <h1>Unable to Calculate Discount</h1>");
            out.println("  <p class=\"error\">" + escapeHtml(message) + "</p>");
            out.println("  <a href=\"" + request.getContextPath() + "/\">Go back</a>");
            pageEnd(out);
        }
    }

    private void pageStart(PrintWriter out, String title) {
        out.println("<!DOCTYPE html>");
        out.println("<html lang=\"en\"><head>");
        out.println("  <meta charset=\"UTF-8\">");
        out.println("  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
        out.println("  <title>" + escapeHtml(title) + "</title>");
        out.println("  <style>body{font-family:Arial,sans-serif;margin:10vh auto;padding:24px;max-width:700px;background:#f1f5f9;color:#172554}.card{padding:32px;background:white;border-radius:12px;box-shadow:0 12px 32px #0f17221f}h1{text-align:center}dl{display:grid;grid-template-columns:1fr auto;gap:12px 24px}dt{font-weight:600}dd{margin:0;text-align:right}.highlight{color:#15803d;font-weight:700}.error{color:#b91c1c;text-align:center}a{display:inline-block;margin-top:18px;padding:10px 18px;border-radius:6px;background:#1b2a7a;color:white;text-decoration:none}</style>");
        out.println("</head><body><main class=\"card\">");
    }

    private void pageEnd(PrintWriter out) {
        out.println("</main></body></html>");
    }

    private static String escapeHtml(String value) {
        return value.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}
