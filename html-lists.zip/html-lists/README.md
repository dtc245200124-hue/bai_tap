# Thực hành tạo danh sách trong HTML

Mở file `index.html` bằng Chrome, Firefox hoặc Edge để xem kết quả.

Trang sử dụng:

- `<ul>` cho danh sách mua sắm không có thứ tự;
- `<ol>` cho danh sách công việc có đánh số;
- `<li>` cho từng mục danh sách;
- `<ol type="A">` để đánh số bằng chữ cái;
- Danh sách `<ul>` lồng bên trong `<ol>`.

## Chạy bài

Nhấp đúp vào `index.html`, hoặc mở bằng trình duyệt:

```text
file:///duong-dan-den/html-lists/index.html
```

## Nộp bài

Đưa file `index.html` hoặc toàn bộ thư mục này lên GitHub rồi nộp link repository.
