package com.codegym.calculator;

/**
 * Performs the four basic arithmetic operations.
 */
public class Calculator {

    private Calculator() {
        // Utility class.
    }

    /**
     * Calculates a result for the supplied operands and operator.
     *
     * @throws ArithmeticException when dividing by zero
     * @throws IllegalArgumentException when the operator is unsupported
     */
    public static double calculate(double firstOperand, double secondOperand, char operator) {
        return switch (operator) {
            case '+' -> firstOperand + secondOperand;
            case '-' -> firstOperand - secondOperand;
            case '*' -> firstOperand * secondOperand;
            case '/' -> {
                if (secondOperand == 0) {
                    throw new ArithmeticException("Không thể chia cho 0.");
                }
                yield firstOperand / secondOperand;
            }
            default -> throw new IllegalArgumentException("Toán tử không hợp lệ.");
        };
    }
}
