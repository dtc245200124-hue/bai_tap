package com.codegym.calculator;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.text.DecimalFormat;

@WebServlet(name = "calculatorServlet", urlPatterns = "/calculator")
public class CalculatorServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String firstInput = request.getParameter("firstOperand");
        String secondInput = request.getParameter("secondOperand");
        String operatorInput = request.getParameter("operator");

        try {
            DecimalFormat numberFormat = new DecimalFormat("0.##########");
            double firstOperand = Double.parseDouble(firstInput);
            double secondOperand = Double.parseDouble(secondInput);
            char operator = operatorInput == null || operatorInput.isEmpty()
                    ? '+' : operatorInput.charAt(0);

            double result = Calculator.calculate(firstOperand, secondOperand, operator);
            request.setAttribute("firstOperand", numberFormat.format(firstOperand));
            request.setAttribute("secondOperand", numberFormat.format(secondOperand));
            request.setAttribute("operator", String.valueOf(operator));
            request.setAttribute("result", numberFormat.format(result));
        } catch (NullPointerException | NumberFormatException e) {
            request.setAttribute("errorMessage", "Vui lòng nhập hai toán hạng hợp lệ.");
        } catch (ArithmeticException | IllegalArgumentException e) {
            request.setAttribute("errorMessage", e.getMessage());
        }

        request.getRequestDispatcher("/result.jsp").forward(request, response);
    }
}
