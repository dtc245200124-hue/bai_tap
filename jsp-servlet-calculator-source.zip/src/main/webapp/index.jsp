<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Máy tính đơn giản</title>
    <style>
        :root { --primary: #2563eb; --background: #f1f5f9; --text: #0f172a; }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px; font-family: Arial, sans-serif; background: var(--background); color: var(--text); }
        .calculator { width: min(100%, 430px); padding: 36px; border-radius: 14px; background: #fff; box-shadow: 0 8px 24px rgba(15, 23, 42, .12); }
        h1 { margin: 0 0 8px; color: var(--primary); text-align: center; }
        .description { margin: 0 0 28px; color: #64748b; text-align: center; }
        label { display: block; margin: 16px 0 7px; font-weight: 700; }
        input, select { width: 100%; padding: 12px 14px; border: 1px solid #cbd5e1; border-radius: 7px; font-size: 16px; }
        button { width: 100%; margin-top: 24px; padding: 13px; border: 0; border-radius: 7px; background: var(--primary); color: white; font-size: 16px; font-weight: 700; cursor: pointer; }
        button:hover { background: #1d4ed8; }
    </style>
</head>
<body>
<main class="calculator">
    <h1>Máy tính</h1>
    <p class="description">Thực hiện các phép tính cơ bản</p>
    <form action="calculator" method="post">
        <label for="firstOperand">Toán hạng 1</label>
        <input id="firstOperand" type="number" name="firstOperand" step="any" required>

        <label for="operator">Toán tử</label>
        <select id="operator" name="operator">
            <option value="+">Cộng (+)</option>
            <option value="-">Trừ (-)</option>
            <option value="*">Nhân (*)</option>
            <option value="/">Chia (/)</option>
        </select>

        <label for="secondOperand">Toán hạng 2</label>
        <input id="secondOperand" type="number" name="secondOperand" step="any" required>

        <button type="submit">Tính toán</button>
    </form>
</main>
</body>
</html>
