<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kết quả tính toán</title>
    <style>
        :root { --primary: #2563eb; --background: #f1f5f9; }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px; font-family: Arial, sans-serif; background: var(--background); }
        .result { width: min(100%, 480px); padding: 36px; border-radius: 14px; background: #fff; box-shadow: 0 8px 24px rgba(15, 23, 42, .12); text-align: center; }
        h1 { margin: 0 0 24px; color: var(--primary); }
        .calculation { margin: 0 0 22px; color: #475569; font-size: 20px; }
        .answer { padding: 20px; border-radius: 9px; background: #dcfce7; color: #166534; font-size: 28px; font-weight: 700; }
        .error { padding: 20px; border-radius: 9px; background: #fee2e2; color: #b91c1c; font-size: 18px; }
        .back { display: inline-block; margin-top: 24px; padding: 11px 20px; border-radius: 7px; background: var(--primary); color: white; text-decoration: none; font-weight: 700; }
        .back:hover { background: #1d4ed8; }
    </style>
</head>
<body>
<main class="result">
    <h1>Kết quả</h1>
    <% if (request.getAttribute("errorMessage") != null) { %>
        <div class="error"><%= request.getAttribute("errorMessage") %></div>
    <% } else { %>
        <p class="calculation">
            <%= request.getAttribute("firstOperand") %>
            <%= request.getAttribute("operator") %>
            <%= request.getAttribute("secondOperand") %>
            =
        </p>
        <div class="answer"><%= request.getAttribute("result") %></div>
    <% } %>
    <a class="back" href="index.jsp">Tính phép khác</a>
</main>
</body>
</html>
