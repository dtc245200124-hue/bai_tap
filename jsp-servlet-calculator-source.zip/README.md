# Servlet JSP Calculator

Ứng dụng Java Web dùng Servlet và JSP để thực hiện bốn phép tính: cộng, trừ, nhân và chia. Ứng dụng xử lý lỗi khi người dùng chia cho 0 hoặc nhập dữ liệu không hợp lệ.

## Yêu cầu

- JDK 17+
- Maven 3.8+
- Apache Tomcat 10.1+

## Chạy dự án

Từ thư mục gốc dự án:

```bash
mvn clean package
```

Sao chép file `target/jsp-servlet-calculator.war` vào thư mục `webapps` của Tomcat, khởi động Tomcat và truy cập:

```text
http://localhost:8080/jsp-servlet-calculator/
```

## Luồng xử lý

1. `index.jsp` hiển thị form nhập hai toán hạng và chọn toán tử.
2. `CalculatorServlet` nhận dữ liệu POST tại đường dẫn `/calculator`.
3. Lớp `Calculator` thực hiện phép tính.
4. Servlet chuyển tiếp sang `result.jsp` để hiển thị kết quả hoặc lỗi.
