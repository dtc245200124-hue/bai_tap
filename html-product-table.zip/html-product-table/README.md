# Bài tập tạo bảng danh sách sản phẩm trong HTML

Mở file `index.html` bằng trình duyệt để xem kết quả.

Trang đã có tiêu đề **Danh sách sản phẩm** và bảng gồm các cột:

- Tên sản phẩm;
- Giá;
- Số lượng.

Bảng có bốn sản phẩm mẫu: Laptop, Điện thoại thông minh, Tai nghe Bluetooth và Bàn phím cơ.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
