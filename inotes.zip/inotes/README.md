# iNotes - Strategy Pattern

Ứng dụng web quản lý ghi chú bằng Java Servlet/JSP. Mục tiêu là có thể đổi nơi lưu trữ mà không thay đổi controller: lưu vào MySQL hoặc lưu vào file `data/notes.csv`.

## Cấu trúc chính

- `Note`: interface Strategy, khai báo `setTitle`, `setContent`, `setTypeId`, `getTitle`, `getContent`, `getType`, `save`, `delete` và tìm kiếm.
- `NoteDB`: Strategy lưu/truy vấn ghi chú trong MySQL.
- `NoteFile`: Strategy lưu/truy vấn ghi chú trong file dạng `id|title|content|typeId|type`.
- `NoteManagement`: Context, chứa Strategy hiện tại và có `changeNoteStore(storeType)`.
- `NoteServlet`: giao diện thêm, tìm kiếm, xem chi tiết và xóa ghi chú.

## Cài database

Chạy file `database/schema.sql` bằng MySQL Workbench hoặc:

```bash
mysql -u root -p < database/schema.sql
```

Mặc định kết nối là:

```text
jdbc:mysql://localhost:3306/iNotes
user: root
password: 123456
```

Có thể đổi bằng biến môi trường `DB_URL`, `DB_USER`, `DB_PASSWORD`.

## Build và chạy

Yêu cầu Java 11+, Maven và Tomcat 9+:

```bash
mvn clean package
```

Copy `target/inotes.war` vào thư mục `webapps` của Tomcat rồi mở:

```text
http://localhost:8080/inotes/notes?store=db
```

## Chuyển sang lưu file

Mở:

```text
http://localhost:8080/inotes/notes?store=file
```

Các ghi chú mới sẽ được lưu vào `data/notes.csv`. Trên server, đường dẫn này tương đối với thư mục Tomcat đang chạy. Có thể cấu hình đường dẫn tuyệt đối bằng biến môi trường `INOTES_FILE`.

Trang tìm kiếm cũng có lựa chọn **Cả hai nơi lưu trữ**, khi đó `NoteManagement.searchAllStores()` tìm trong cả MySQL và file.

## Kiểm tra Strategy

1. Chạy với `store=db`, thêm một ghi chú và kiểm tra bảng `iNotes.notes`.
2. Chạy với `store=file`, thêm một ghi chú và kiểm tra `data/notes.csv`.
3. Chọn **Cả hai nơi lưu trữ** để tìm kiếm trong cả hai backend.
4. Đọc `NoteManagement.changeNoteStore()` để thấy việc chuyển Strategy không làm thay đổi servlet.

## Đưa lên GitHub

```bash
git init
git add .
git commit -m "Complete iNotes Strategy pattern case study"
git branch -M main
git remote add origin https://github.com/<username>/<repository>.git
git push -u origin main
```

Không commit mật khẩu MySQL thật lên GitHub; dùng biến môi trường khi triển khai.
