package com.codegym.inotes.repository;

import com.codegym.inotes.model.Note;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class NoteFile implements Note {
    private static final Path FILE = Paths.get(System.getenv().getOrDefault("INOTES_FILE", "data/notes.csv"));
    private int id;
    private String title;
    private String content;
    private int typeId;
    private String type;

    public NoteFile() {}
    public NoteFile(int id, String title, String content, int typeId, String type) {
        this.id=id; this.title=title; this.content=content; this.typeId=typeId; this.type=type;
    }

    @Override public void setId(int id) { this.id=id; }
    @Override public int getId() { return id; }
    @Override public void setTitle(String title) { this.title=title; }
    @Override public String getTitle() { return title; }
    @Override public void setContent(String content) { this.content=content; }
    @Override public String getContent() { return content; }
    @Override public void setTypeId(int typeId) { this.typeId=typeId; }
    @Override public int getTypeId() { return typeId; }
    @Override public String getType() { return type == null || type.isBlank() ? typeName(typeId) : type; }

    @Override
    public synchronized void save() throws Exception {
        List<NoteFile> notes = readAll();
        if (id == 0) id = notes.stream().mapToInt(NoteFile::getId).max().orElse(0) + 1;
        notes.removeIf(note -> note.id == id);
        notes.add(this);
        writeAll(notes);
    }

    @Override
    public synchronized void delete() throws Exception {
        writeAll(readAll().stream().filter(note -> note.id != id).collect(Collectors.toList()));
    }

    @Override
    public synchronized List<Note> search(String keyword) throws Exception {
        String value = keyword == null ? "" : keyword.trim().toLowerCase();
        return readAll().stream().filter(note -> note.title.toLowerCase().contains(value) || note.content.toLowerCase().contains(value))
                .sorted(Comparator.comparingInt(NoteFile::getId).reversed()).map(note -> (Note) note).collect(Collectors.toList());
    }

    @Override
    public synchronized Note findById(int id) throws Exception {
        return readAll().stream().filter(note -> note.id == id).findFirst().orElse(null);
    }

    private static List<NoteFile> readAll() throws Exception {
        if (!Files.exists(FILE)) return new ArrayList<>();
        List<NoteFile> result = new ArrayList<>();
        for (String line : Files.readAllLines(FILE, StandardCharsets.UTF_8)) {
            if (line.isBlank() || line.startsWith("id|")) continue;
            String[] parts = line.split("\\|", -1);
            if (parts.length >= 5) result.add(new NoteFile(Integer.parseInt(parts[0]), unescape(parts[1]), unescape(parts[2]), Integer.parseInt(parts[3]), unescape(parts[4])));
        }
        return result;
    }

    private static void writeAll(List<NoteFile> notes) throws Exception {
        if (FILE.getParent() != null) Files.createDirectories(FILE.getParent());
        List<String> lines = new ArrayList<>(); lines.add("id|title|content|typeId|type");
        for (NoteFile note : notes) lines.add(note.id + "|" + escape(note.title) + "|" + escape(note.content) + "|" + note.typeId + "|" + escape(note.getType()));
        Files.write(FILE, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }

    private static String escape(String value) { return (value == null ? "" : value).replace("\\", "\\\\").replace("|", "\\p").replace("\n", "\\n"); }
    private static String unescape(String value) { return value.replace("\\n", "\n").replace("\\p", "|").replace("\\\\", "\\"); }
    private static String typeName(int id) { return id == 1 ? "Công việc" : id == 2 ? "Cá nhân" : id == 3 ? "Học tập" : "Khác"; }
}
