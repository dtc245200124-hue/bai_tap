package com.codegym.inotes.service;

import com.codegym.inotes.model.Note;
import com.codegym.inotes.repository.NoteDB;
import com.codegym.inotes.repository.NoteFile;

import java.util.ArrayList;
import java.util.List;

public class NoteManagement {
    private Note note;
    private String storeType;

    public NoteManagement(String storeType) { changeNoteStore(storeType); }

    public final void changeNoteStore(String storeType) {
        this.storeType = "file".equalsIgnoreCase(storeType) ? "file" : "db";
        this.note = "file".equals(this.storeType) ? new NoteFile() : new NoteDB();
    }

    public String getStoreType() { return storeType; }

    public void addNote(String title, String content, int typeId) throws Exception {
        note.setId(0); note.setTitle(title); note.setContent(content); note.setTypeId(typeId); note.save();
    }

    public void updateNote(int id, String title, String content, int typeId) throws Exception {
        Note existing = note.findById(id);
        if (existing == null) throw new IllegalArgumentException("Không tìm thấy ghi chú");
        existing.setTitle(title); existing.setContent(content); existing.setTypeId(typeId); existing.save();
    }

    public void deleteNote(int id) throws Exception {
        note.setId(id); note.delete();
    }

    public List<Note> searchNotes(String keyword) throws Exception {
        return note.search(keyword);
    }

    /** Search both stores, useful for the unified search screen. */
    public List<Note> searchAllStores(String keyword) throws Exception {
        List<Note> result = new ArrayList<>();
        result.addAll(new NoteDB().search(keyword));
        result.addAll(new NoteFile().search(keyword));
        return result;
    }

    public Note findById(int id) throws Exception { return note.findById(id); }
}
