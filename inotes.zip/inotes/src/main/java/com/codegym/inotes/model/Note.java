package com.codegym.inotes.model;

import java.io.IOException;
import java.util.List;

/** Strategy contract for storing and searching notes. */
public interface Note {
    void setId(int id);
    int getId();
    void setTitle(String title);
    String getTitle();
    void setContent(String content);
    String getContent();
    void setTypeId(int typeId);
    int getTypeId();
    String getType();
    void save() throws Exception;
    void delete() throws Exception;
    List<Note> search(String keyword) throws Exception;
    Note findById(int id) throws Exception;
}
