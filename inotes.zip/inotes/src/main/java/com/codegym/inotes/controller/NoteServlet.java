package com.codegym.inotes.controller;

import com.codegym.inotes.model.Note;
import com.codegym.inotes.service.NoteManagement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/notes/*")
public class NoteServlet extends HttpServlet {
    private NoteManagement management(HttpServletRequest request) {
        String store = request.getParameter("store");
        if (store == null) store = (String) request.getSession().getAttribute("store");
        if (store == null) store = "db";
        request.getSession().setAttribute("store", store);
        return new NoteManagement(store);
    }

    @Override protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getPathInfo();
        try {
            NoteManagement service = management(request);
            if ("/new".equals(path)) {
                request.getRequestDispatcher("/WEB-INF/views/form.jsp").forward(request, response); return;
            }
            if ("/detail".equals(path)) {
                request.setAttribute("note", service.findById(Integer.parseInt(request.getParameter("id"))));
                request.getRequestDispatcher("/WEB-INF/views/detail.jsp").forward(request, response); return;
            }
            String keyword = request.getParameter("keyword");
            List<Note> notes = "all".equalsIgnoreCase(request.getParameter("store")) ? service.searchAllStores(keyword) : service.searchNotes(keyword);
            request.setAttribute("notes", notes); request.setAttribute("keyword", keyword == null ? "" : keyword);
            request.getRequestDispatcher("/WEB-INF/views/list.jsp").forward(request, response);
        } catch (Exception e) { throw new ServletException("Không thể xử lý ghi chú", e); }
    }

    @Override protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        try {
            NoteManagement service = management(request);
            String action = request.getParameter("action");
            if ("save".equals(action)) {
                String id = request.getParameter("id");
                if (id == null || id.isBlank()) service.addNote(request.getParameter("title"), request.getParameter("content"), Integer.parseInt(request.getParameter("typeId")));
                else service.updateNote(Integer.parseInt(id), request.getParameter("title"), request.getParameter("content"), Integer.parseInt(request.getParameter("typeId")));
            } else if ("delete".equals(action)) service.deleteNote(Integer.parseInt(request.getParameter("id")));
            response.sendRedirect(request.getContextPath() + "/notes?store=" + service.getStoreType());
        } catch (Exception e) { throw new ServletException("Không thể lưu/xóa ghi chú", e); }
    }
}
