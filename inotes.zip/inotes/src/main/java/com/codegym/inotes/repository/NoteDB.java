package com.codegym.inotes.repository;

import com.codegym.inotes.model.Note;
import com.codegym.inotes.util.ConnectionUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class NoteDB implements Note {
    private int id;
    private String title;
    private String content;
    private int typeId;
    private String type;

    public NoteDB() {}
    public NoteDB(int id, String title, String content, int typeId, String type) {
        this.id = id; this.title = title; this.content = content; this.typeId = typeId; this.type = type;
    }

    @Override public void setId(int id) { this.id = id; }
    @Override public int getId() { return id; }
    @Override public void setTitle(String title) { this.title = title; }
    @Override public String getTitle() { return title; }
    @Override public void setContent(String content) { this.content = content; }
    @Override public String getContent() { return content; }
    @Override public void setTypeId(int typeId) { this.typeId = typeId; }
    @Override public int getTypeId() { return typeId; }
    @Override public String getType() { return type; }

    @Override
    public void save() throws Exception {
        String sql = id == 0
                ? "INSERT INTO notes(title, content, type_id) VALUES (?, ?, ?)"
                : "UPDATE notes SET title = ?, content = ?, type_id = ? WHERE id = ?";
        try (Connection connection = ConnectionUtils.getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, title); statement.setString(2, content); statement.setInt(3, typeId);
            if (id != 0) statement.setInt(4, id);
            statement.executeUpdate();
        }
    }

    @Override
    public void delete() throws Exception {
        try (Connection connection = ConnectionUtils.getConnection(); PreparedStatement statement = connection.prepareStatement("DELETE FROM notes WHERE id = ?")) {
            statement.setInt(1, id); statement.executeUpdate();
        }
    }

    @Override
    public List<Note> search(String keyword) throws Exception {
        List<Note> notes = new ArrayList<>();
        String sql = "SELECT n.id, n.title, n.content, n.type_id, t.name AS type_name " +
                "FROM notes n JOIN note_types t ON n.type_id = t.id " +
                "WHERE n.title LIKE ? OR n.content LIKE ? ORDER BY n.id DESC";
        try (Connection connection = ConnectionUtils.getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            String value = "%" + (keyword == null ? "" : keyword.trim()) + "%";
            statement.setString(1, value); statement.setString(2, value);
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) notes.add(from(result));
            }
        }
        return notes;
    }

    @Override
    public Note findById(int id) throws Exception {
        String sql = "SELECT n.id, n.title, n.content, n.type_id, t.name AS type_name FROM notes n JOIN note_types t ON n.type_id=t.id WHERE n.id=?";
        try (Connection connection = ConnectionUtils.getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet result = statement.executeQuery()) { return result.next() ? from(result) : null; }
        }
    }

    private NoteDB from(ResultSet result) throws Exception {
        return new NoteDB(result.getInt("id"), result.getString("title"), result.getString("content"),
                result.getInt("type_id"), result.getString("type_name"));
    }
}
