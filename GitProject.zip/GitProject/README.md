# GitProject

Project thực hành các thao tác cơ bản với Git và GitHub.

## Nội dung

- Khởi tạo repository local;
- Clone repository từ GitHub;
- Tạo và commit file README;
- Tạo thư mục `source` chứa các file HTML;
- Push mã nguồn lên nhánh `main` trên GitHub.

## Chạy thử

Mở `source/index.html` hoặc `source/news.html` bằng trình duyệt web.

## Liên kết GitHub

Sau khi tạo repository GitHub, thay `<username>` bằng tên tài khoản của bạn:

```bash
git remote add origin https://github.com/<username>/GitProject.git
git push -u origin main
```
