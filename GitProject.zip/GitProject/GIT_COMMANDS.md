# Các lệnh Git đã sử dụng

```bash
git init -b main
```
Khởi tạo repository local và tạo nhánh chính tên `main`.

```bash
git add README.md
git commit -m "Add README.md"
```
Đưa README vào staging area và lưu thành commit đầu tiên.

```bash
git add source/
git commit -m "Add source files"
```
Đưa toàn bộ thư mục `source` vào staging area và lưu commit thứ hai.

```bash
git remote add origin https://github.com/<username>/GitProject.git
git push -u origin main
```
Kết nối repository local với GitHub và đẩy nhánh `main` lên remote `origin`.

Nếu Git chưa có thông tin người dùng:

```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```
