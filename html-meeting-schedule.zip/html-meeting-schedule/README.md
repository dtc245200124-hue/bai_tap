# Bài tập gộp ô trong bảng với rowspan và colspan

Mở file `index.html` bằng trình duyệt để xem kết quả.

Bảng có các cột **Ngày**, **Giờ** và **Nội dung cuộc họp**.

- `rowspan="2"` gộp ô ngày Thứ Hai cho hai cuộc họp trong cùng ngày;
- `colspan="2"` gộp cột Giờ và Nội dung cuộc họp cho hội thảo kéo dài từ 09:00 đến 12:00.

Đưa toàn bộ thư mục lên GitHub rồi nộp link repository.
