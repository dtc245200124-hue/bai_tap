# User Management JDBC và Stored Procedures

Ứng dụng Java Web quản lý User theo MVC, sử dụng Servlet, JSP, JSTL, JDBC và MySQL. Ứng dụng hỗ trợ CRUD, tìm kiếm theo `country`, sắp xếp theo `name`, đồng thời dùng Stored Procedure cho hai chức năng: tìm User theo ID và thêm User mới.

## Stored Procedures

File `schema.sql` tạo hai thủ tục MySQL:

```text
get_user_by_id(IN user_id INT)
insert_user(IN user_name, IN user_email, IN user_country)
```

`UserDAO.getUserById()` gọi thủ tục đầu tiên bằng `CallableStatement` với cú pháp `{CALL get_user_by_id(?)}`. `UserDAO.insertUserStore()` gọi thủ tục thứ hai bằng `{CALL insert_user(?, ?, ?)}`. `UserServlet` dùng các phương thức này trong luồng mở form sửa và thêm User.

## Khởi tạo MySQL

Chạy toàn bộ file `schema.sql` trong MySQL Workbench, DBeaver hoặc terminal. Script tạo database `demo`, bảng `users`, dữ liệu mẫu và hai Stored Procedure. Script có `DROP PROCEDURE IF EXISTS` để có thể chạy lại phần procedure.

## Cấu hình kết nối

Thiết lập các biến môi trường sau trước khi chạy Tomcat:

```text
USER_DB_URL=jdbc:mysql://localhost:3306/demo?useSSL=false&serverTimezone=UTC
USER_DB_USERNAME=root
USER_DB_PASSWORD=your-password
```

Không đưa mật khẩu thật lên GitHub.

## Chạy dự án

```bash
mvn clean package
```

Sao chép `target/user-management.war` vào thư mục `webapps` của Tomcat 10.1+, khởi động Tomcat rồi truy cập:

```text
http://localhost:8080/user-management/users
```
