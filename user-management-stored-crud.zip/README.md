# User Management JDBC, Stored Procedures và Transaction

Ứng dụng Java Web quản lý User theo MVC, sử dụng Servlet, JSP, JSTL, JDBC và MySQL. Ứng dụng hỗ trợ CRUD, tìm kiếm theo `country`, sắp xếp theo `name`, Stored Procedure và các bài thực hành transaction.

## Stored Procedure cho User CRUD

Các luồng hiển thị danh sách, sửa và xoá User hiện gọi MySQL Stored Procedure qua `CallableStatement`:

```text
select_all_users()
update_user(user_id, user_name, user_email, user_country)
delete_user(user_id)
```

`get_user_by_id()` tiếp tục được dùng để tải dữ liệu cho form sửa, còn `insert_user()` và transaction thêm User cùng Permission vẫn được giữ lại từ các bài trước. File `schema.sql` có đầy đủ lệnh tạo các procedure.

Tìm kiếm theo `country` và sắp xếp theo `name` vẫn dùng các truy vấn riêng để minh hoạ các kỹ thuật JDBC khác nhau; danh sách mặc định, cập nhật và xoá đã chuyển sang `CallableStatement`.

## Transaction

Form thêm User cho phép chọn nhiều quyền. `UserDAO.addUserTransaction()` tắt auto-commit, thêm User với generated key, thêm các cặp `user_id`/`permission_id`, rồi `commit()`. Nếu bất kỳ bước nào lỗi, phương thức gọi `rollback()`.

## Khởi tạo MySQL

Chạy toàn bộ file `schema.sql` trong MySQL Workbench, DBeaver hoặc terminal. Script tạo database `demo`, các bảng `users`, `permission`, `user_permission`, `Employee`, dữ liệu mẫu và toàn bộ Stored Procedure.

## Cấu hình kết nối

Thiết lập các biến môi trường sau trước khi chạy Tomcat:

```text
USER_DB_URL=jdbc:mysql://localhost:3306/demo?useSSL=false&serverTimezone=UTC
USER_DB_USERNAME=root
USER_DB_PASSWORD=your-password
```

Không đưa mật khẩu thật lên GitHub.

## Chạy dự án

```bash
mvn clean package
```

Sao chép `target/user-management.war` vào thư mục `webapps` của Tomcat 10.1+, khởi động Tomcat rồi truy cập:

```text
http://localhost:8080/user-management/users
```
