package com.codegym.controller;

import com.codegym.dao.UserDAO;
import com.codegym.model.User;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/** Handles user CRUD, country filtering, and name sorting. */
@WebServlet(name = "UserServlet", urlPatterns = "/users")
public class UserServlet extends HttpServlet {
    private UserDAO userDAO;

    @Override
    public void init() {
        userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = valueOrDefault(request.getParameter("action"), "list");
        try {
            switch (action) {
                case "create" -> forward(request, response, "user/create.jsp");
                case "edit" -> showUserForm(request, response, "user/edit.jsp");
                case "delete" -> showUserForm(request, response, "user/delete.jsp");
                case "search" -> listUsers(request, response, false);
                case "sort" -> listUsers(request, response, true);
                case "test-without-tran" -> testWithoutTransaction(request, response);
                case "test-use-tran" -> testUseTransaction(request, response);
                default -> listUsers(request, response, false);
            }
        } catch (SQLException | NumberFormatException e) {
            throw new ServletException("Không thể tải dữ liệu người dùng.", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = valueOrDefault(request.getParameter("action"), "");
        try {
            switch (action) {
                case "create" -> {
                    userDAO.addUserTransaction(readUser(request, 0), readPermissionIds(request));
                    response.sendRedirect(request.getContextPath() + "/users");
                }
                case "edit" -> {
                    userDAO.updateUserStore(readUser(request, Integer.parseInt(request.getParameter("id"))));
                    response.sendRedirect(request.getContextPath() + "/users");
                }
                case "delete" -> {
                    userDAO.deleteUserStore(Integer.parseInt(request.getParameter("id")));
                    response.sendRedirect(request.getContextPath() + "/users");
                }
                default -> response.sendRedirect(request.getContextPath() + "/users");
            }
        } catch (SQLException | NumberFormatException e) {
            throw new ServletException("Không thể cập nhật dữ liệu người dùng.", e);
        }
    }

    private void listUsers(HttpServletRequest request, HttpServletResponse response, boolean sorted)
            throws SQLException, ServletException, IOException {
        String country = request.getParameter("country");
        List<User> users;
        if (sorted) {
            users = userDAO.selectAllUsersSortedByName();
        } else if (country == null || country.isBlank()) {
            users = userDAO.selectAllUsersStore();
        } else {
            users = userDAO.searchByCountry(country);
        }
        request.setAttribute("users", users);
        request.setAttribute("country", country == null ? "" : country);
        request.setAttribute("sorted", sorted);
        forward(request, response, "user/list.jsp");
    }

    private void showUserForm(HttpServletRequest request, HttpServletResponse response, String view)
            throws SQLException, ServletException, IOException {
        User user = userDAO.getUserById(Integer.parseInt(request.getParameter("id")));
        if (user == null) {
            forward(request, response, "user/not-found.jsp");
            return;
        }
        request.setAttribute("user", user);
        forward(request, response, view);
    }

    private User readUser(HttpServletRequest request, int id) {
        return new User(id, request.getParameter("name"), request.getParameter("email"),
                request.getParameter("country"));
    }

    private int[] readPermissionIds(HttpServletRequest request) {
        String[] values = request.getParameterValues("permissions");
        if (values == null) {
            return new int[0];
        }
        int[] permissionIds = new int[values.length];
        for (int index = 0; index < values.length; index++) {
            permissionIds[index] = Integer.parseInt(values[index]);
        }
        return permissionIds;
    }

    private void testWithoutTransaction(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        userDAO.insertUpdateWithoutTransaction();
        response.setContentType("text/plain; charset=UTF-8");
        response.getWriter().println(
                "Đã chạy bài kiểm thử không dùng transaction. Hãy kiểm tra bảng Employee trong MySQL.");
    }

    private void testUseTransaction(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        userDAO.insertUpdateUseTransaction();
        response.setContentType("text/plain; charset=UTF-8");
        response.getWriter().println(
                "Đã chạy bài kiểm thử dùng transaction. Hãy kiểm tra bảng Employee trong MySQL.");
    }

    private void forward(HttpServletRequest request, HttpServletResponse response, String path)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher(path);
        dispatcher.forward(request, response);
    }

    private String valueOrDefault(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }
}
