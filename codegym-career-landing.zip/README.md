# CodeGym Career — Material Design Landing Page

Landing page thực hành cho bài tập xây dựng Landing Page CodeGym Career bằng HTML, CSS, JavaScript, Bootstrap và MDBootstrap/Material Design.

## Nội dung đã triển khai

- Navbar responsive với menu điều hướng.
- Hero section giới thiệu chương trình Coding Bootcamp 20 tuần.
- Các card lợi ích: học từ con số 0, học qua dự án, trải nghiệm doanh nghiệp, hỗ trợ nghề nghiệp.
- Timeline lộ trình học từ nền tảng đến sẵn sàng đi làm.
- Phần dịch vụ việc làm, testimonial và CTA.
- Form đăng ký tư vấn có kiểm tra dữ liệu phía trình duyệt.
- Footer và nút quay lại đầu trang.

## Chạy dự án

Mở trực tiếp file `index.html` bằng trình duyệt. Vì Bootstrap, MDBootstrap, Font Awesome và Google Fonts được tải từ CDN, cần có kết nối Internet.

Hoặc chạy server tĩnh:

```bash
python3 -m http.server 5500
```

Sau đó mở `http://localhost:5500`.

## Nộp GitHub/CodePen

Upload các file `index.html`, `style.css`, `script.js` và `README.md` lên GitHub. Nếu dùng CodePen, copy phần HTML trong `index.html`, CSS trong `style.css` và JS trong `script.js` vào ba khung tương ứng.

## Nguồn nội dung

Nội dung được tham khảo từ trang CodeGym Career:
https://codegym.vn/codegym-career/

Hình minh họa hero được tạo bằng CSS/code window để dự án chạy độc lập, không phụ thuộc ảnh bản quyền bên ngoài.
