$(function () {
  $('.navbar-nav a[href^="#"]').on('click', function () {
    $('.navbar-collapse').collapse('hide');
  });

  $(window).on('scroll', function () {
    if ($(this).scrollTop() > 500) {
      $('#backToTop').addClass('show');
    } else {
      $('#backToTop').removeClass('show');
    }
  });

  $('#backToTop').on('click', function () {
    $('html, body').animate({ scrollTop: 0 }, 500);
  });

  $('#careerForm').on('submit', function (event) {
    event.preventDefault();
    const form = this;
    const message = $('#formMessage');
    if (!form.checkValidity()) {
      message.text('Vui lòng điền đầy đủ các trường bắt buộc.').removeClass('text-success').addClass('text-danger');
      form.classList.add('was-validated');
      return;
    }
    message.text('Đã nhận thông tin! Đội ngũ CodeGym sẽ liên hệ với bạn sớm.').removeClass('text-danger').addClass('text-success');
    form.reset();
    form.classList.remove('was-validated');
  });
});
