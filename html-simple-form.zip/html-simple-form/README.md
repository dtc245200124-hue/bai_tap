# Thực hành tạo form cơ bản

Mở file `simpleform.html` bằng trình duyệt để xem và thử form.

Form đã có đầy đủ các phần tử yêu cầu:

- Select chọn sản phẩm A, B hoặc C;
- Radio button chọn số lượng;
- Text field nhập họ và tên;
- Ô nhập email;
- Ba ô nhập số điện thoại;
- Nút Submit;
- Font chữ `Lucida Grande`, `Lucida Sans Unicode`, `Tahoma`, `sans-serif` thông qua class `wufoo`.

Form sử dụng:

```html
<form method="get" action="simpleform.html" class="wufoo">
```

Đưa file `simpleform.html` hoặc toàn bộ thư mục lên GitHub rồi nộp link repository.
